//
//  ContentView.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/16.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        ZStack {
            NavigationView {
                HomeListView()
                    .navigationBarTitle("App")
                    .background(Color.init(white: 0.9).edgesIgnoringSafeArea(.all))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
