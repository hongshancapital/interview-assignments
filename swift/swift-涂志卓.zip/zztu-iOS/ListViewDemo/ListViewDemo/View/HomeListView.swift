//
//  HomeListView.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/19.
//

import SwiftUI

struct HomeListView: View {
    
    @StateObject var viewModel = HomeViewModel()
    
    private var items: [HomeData] {
        viewModel.dataArray
    }
    
    var body: some View {
        ZStack {
            ScrollView {
                /// List
                ForEach(items) { item in
                    HomeMarkRow(homeData: item)
                }
                /// 刷新尾
                RefreshFooter(refreshing: $viewModel.footerRefreshing, action: {
                    viewModel.loadMore(success: { }, fail: { _ in })
                }) {
                    if viewModel.noMore {
                        Text("No more data !")
                            .foregroundColor(.secondary)
                            .padding()
                    } else {
                        ProgressView()
                    }
                }
                .noMore(viewModel.noMore)
                .preload(offset: -50)
            }
            .enableRefresh()
            .onAppear() {
                viewModel.reload(success: { }, fail: { _ in })
            }
            /// 错误提示
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(title: Text("App Error"),
                      message: Text(viewModel.appError.localizedDescription),
                      dismissButton: .default(Text("OK")))
            }
            
            if items.isEmpty {
                ProgressView()
            }
            
        }
    }
}

struct HomeListView_Previews: PreviewProvider {
    static var previews: some View {
        HomeListView()
    }
}
