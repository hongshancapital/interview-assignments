//
//  SwiftUIView.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/16.
//

import SwiftUI

struct HomeMarkRow: View {
    var homeData: HomeData
    
    var body: some View {
        HStack {
            HStack {} .frame(width: 12).background(Color.clear)
            
            HStack(alignment: .top) {
                AsynImage(
                    url:  URL(string: homeData.artworkUrl60)!,
                    placeholder: { ProgressView() },
                    image: {
                        Image(uiImage: $0).resizable() }
                )
                    .frame(width: 50, height: 50)
                    .cornerRadius(8)
                    .padding([.top, .bottom],10)
                
                VStack(alignment: .leading) {
                    Text(homeData.trackName)
                        .bold()
                        .padding(.top,10)
                        .lineLimit(1)
                    
                    Text(homeData.description)
                        .font(.caption2)
                        .offset(y: 5)
                        .lineLimit(2)
                }
                Spacer()
            }
            .padding([.leading, .trailing],12)
            .background(Color.white)
            .cornerRadius(12)
            
            HStack {} .frame(width: 12).background(Color.clear)
        }
    }
}

//struct SwiftUIView_Previews: PreviewProvider {
//    var viewModel = HomeViewModel()
//
//    static var previews: some View {
//        viewModel.reload()
//        HomeMarkRow(homeMark: viewModel.dataArray.first)
//    }
//}
