//
//  ListViewDemoApp.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/16.
//

/** Demo简介 (麻雀虽小, 五脏俱全)
 * 一、项目采用MVVM架构, Model数据模型, View负责页面布局，ViewModel负责数据运算.
 *            View持有ViewModel, 2者双向绑定, viewModel获取数据源刷新View, 同时View事件传递到ViewModel再次请求数据,刷新View.
 *
 * 二、主要实现功能:
 * 1. UI List自定义布局
 * 2. 图片下载组件, 实际项目中可采用成熟的三方库 'Kingfisher'实现.
 * 3. 网络数据请求, 实际项目中可采用成熟的三方库 'Moya'实现.
 * 4. 下拉刷新组件, 没时间自己实现, 网上找的三方库.
 * 5. 错误处理, 出现异常错误会回抛到UI页面弹窗提醒.
 * 6. 单元测试.
 */

/** 一些个人心得
 *
 * 这个Demo并不完美, 还有很多完善的地方, 比如网络层没有抽离封装、页面代码还可以更加简介, 可阅读性还能提高. 但现在您所看到的代码, 确实是用心去实现的.
 * 犹记得前些天刚知道有个面试还有写Demo, 内心其实是拒绝的😂, 其实最主要的原因还是最近工作真的很忙. 之后了解到您公司采用前沿的语言技术, 突然一阵兴奋,我又可以写swift了吗?!
 * swiftUI其实自己并不熟练, 当初swiftUI 1.0出来时练习过一阵, 但是想到如果自己以后能用swiftUI写项目还是比较动心的, 最近抽出时间来花了几天时间, 不懂查资料学习, 完成了这个Demo.
 * 我是一个比较爱学习的人, 希望能用到一些前沿的技术能让代码写的更舒服, 由记得几年前自己努力说服了领导, 允许让我用swift开发项目(武汉大环境很多公司还在继续用OC开发). 后来也学习过rx、swiftUI、flutter, 最近有空也在学前端, 语言要是能用到实际的项目中,那是熟练的最快的.
 * 目前公司的项目依然在用oc开发,swift也好久没写了,如果能有机会和屏幕的你共事, 我会是当初自学swift的激情学好swiftUI, 与你共同进步.
 *
 * 感谢您能看到这里, Best Regards~
 */

import SwiftUI

@main
struct ListViewDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
