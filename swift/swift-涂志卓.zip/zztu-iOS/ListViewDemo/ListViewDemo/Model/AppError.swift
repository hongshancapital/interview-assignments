//
//  AppError.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/19.
//

import Foundation

enum AppError: Error, Identifiable, Equatable, Hashable {
    var id: String { localizedDescription }
    
    /** 简单枚举4种错误类型
     *  1. 网络请求失败
     *  2. 网络图片加载失败
     *  3. 数据解析错误
     *  4. 未知错误
     */
    case networkingFailed
    case webImageFailed
    case parseFailed
    case unknown
}

extension AppError {
    var localizedDescription: String {
        switch self {
        case .networkingFailed:
            return "Networking Failed"
        case .webImageFailed:
            return "WebImage Failed"
        case .parseFailed:
            return "Parse Failed"
        case .unknown:
            return "Un known"
        }
    }
}
