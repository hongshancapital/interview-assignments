//
//  LandMark.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/16.
//

import SwiftUI

struct HomeMark: Codable, Identifiable {
    var id = UUID()
    var resultCount: Int = 0
    var results: [HomeData] = []
    
    enum CodingKeys: String, CodingKey {
           case resultCount, results
    }
}

struct HomeData: Codable, Identifiable {
    var id = UUID()
    var artworkUrl60 = ""
    var trackName = ""
    var description = ""
    
    enum CodingKeys: String, CodingKey {
           case artworkUrl60, trackName, description
    }
}

