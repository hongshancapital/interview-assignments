//
//  HomeViewModel.swift
//  ListViewDemo
//
//  Created by crazyCat on 2022/3/16.
//

import SwiftUI

final class HomeViewModel: ObservableObject {
    
    /// 数据源
    @Published var dataArray: [HomeData] = []
    /// 错误信息
    @Published var appError: AppError = .unknown
    /// 是否显示弹窗
     var showingAlert = false
    /// footer刷新状态
    var footerRefreshing: Bool = false
    /// 数据是否加载完
    var noMore: Bool = false
    /// 分页
    private(set) var page: Int = 1
    
    func reload(success: @escaping ()->Void ,fail: @escaping (AppError)->Void) {
        page = 1
        load(page: page, success: success, fail: fail)
    }
    
    func loadMore(success: @escaping ()->Void ,fail: @escaping (AppError)->Void) {
        page += 1
        load(page: page, success: success, fail: fail)
    }
    
    private  func load(page: Int, success: @escaping ()->Void ,fail: @escaping (AppError)->Void) {
        let limt = 10 * page;
        URLSession.shared.dataTask(with: URL(string: "https://itunes.apple.com/search?entity=software&limit=\(limt)&term=chat")!) { data, _, error in
            if let _ = error {
                DispatchQueue.main.async {
                    self.appError = AppError.networkingFailed
                    self.showingAlert = true
                    fail(self.appError)
                }
            } else {
                /// 网络请求数据过快  故延迟1s加载过程让菊花多转一会
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    if let data = data,
                       let model = try? JSONDecoder().decode(HomeMark.self, from: data) {
                        self.dataArray = model.results
                        self.footerRefreshing = false
                        self.noMore = self.dataArray.count > 50
                        success()
                    } else {
                        fail(AppError.parseFailed)
                    }
                }
            }
        }.resume()
    }
    
}

