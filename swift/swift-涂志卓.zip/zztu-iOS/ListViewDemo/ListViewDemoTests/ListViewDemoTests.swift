//
//  ListViewDemoTests.swift
//  ListViewDemoTests
//
//  Created by crazyCat on 2022/3/16.
//

import XCTest
@testable import ListViewDemo

class ListViewDemoTests: XCTestCase {
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func test_001_net_reload() {
        let viewMode = HomeViewModel()
        let expectation =  expectation(description: "reload data")
        viewMode.reload {
            expectation.fulfill()
        } fail: { error in
            XCTFail(error.localizedDescription)
        }
        
        waitForExpectations(timeout: 10) { error in
            if let _ = error {
                XCTFail("reload fail")
            }
        }
    }
    
    func test_002_net_loadMore() {
        let viewMode = HomeViewModel()
        let expectation =  expectation(description: "loadmore data")
        viewMode.reload {
            expectation.fulfill()
        } fail: { error in
            XCTFail(error.localizedDescription)
        }
        
        waitForExpectations(timeout: 10) { error in
            if let _ = error {
                XCTFail("loadmore fail")
            }
        }
    }
    
    func test_003_picture_load() {
        let url = URL(string: "https://is4-ssl.mzstatic.com/image/thumb/Purple116/v4/b1/87/9a/b1879a2c-6790-a031-cc66-f644bd3dc76c/source/100x100bb.jpg")!
        let loader = ImageLoader(url: url)
        
        /// 等待5s
        DispatchQueue.main.asyncAfter(deadline: .now()+5) {
            if  loader.image == nil {
                XCTFail("load pic fail")
            }
        }
    }
    
}
