import XCTest
@testable import ListViewDemo

final class ListViewDemoTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(ListViewDemo().text, "Hello, World!")
    }
}
