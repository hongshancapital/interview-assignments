//
//  NetworkServiceTests.swift
//  AppTests
//
//  Created by august on 2022/3/10.
//

import XCTest
@testable import App

class NetworkServiceTests: XCTestCase {
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testNetworkPageIndex() async throws {
        let network = NetworkService()
        for _ in 0..<4 {
            try await network.loadData()
            await MainActor.run {
                XCTAssertTrue(network.hasMoreData)
            }
        }
    }

    func testNetwokMockItemCount() async throws {
        let network = NetworkService()
        let requetTimes = Int(4 + arc4random() % 5)
        for _ in 0..<requetTimes {
            try await network.loadData()
            await MainActor.run {
                XCTAssertTrue(network.chatApps.count <= 50)
            }
        }
    }
}
