//
//  NetworkImage.swift
//  App
//
//  Created by august on 2022/3/10.
//

import SwiftUI

struct NetworkImage: View {
    
    var imageUrl: String
    @State @MainActor var image = UIImage()
    @State @MainActor var finished = false
    
    var body: some View {
        ZStack {
            if !finished {
                ProgressView()
                    .progressViewStyle(.circular)
            }
            
            Image(uiImage: image)
                .resizable()
        }
        .onAppear {
            Task(priority: .background) {
                self.image = await ImageLoader.shared.loadImage(with: imageUrl)
                self.finished = true
            }
        }
    }
}

struct NetworkImage_Previews: PreviewProvider {
    static var previews: some View {
        NetworkImage(imageUrl: "https://is4-ssl.mzstatic.com/image/thumb/Purple126/v4/86/a6/bf/86a6bf39-bf4b-25d1-451b-28eef9c15717/source/100x100bb.jpg")
    }
}
