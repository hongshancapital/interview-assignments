//
//  AppApp.swift
//  App
//
//  Created by august on 2022/3/10.
//

import SwiftUI

@main
struct AppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
