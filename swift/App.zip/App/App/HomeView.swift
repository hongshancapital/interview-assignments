//
//  ContentView.swift
//  App
//
//  Created by august on 2022/3/10.
//

import SwiftUI

struct HomeView: View {
    @State var showNetworkErrorNotify = false
    @ObservedObject var network = NetworkService()
        
    var body: some View {
        NavigationView {
            ZStack {
                List {
                    ForEach(network.chatApps, id: \.bundleId) { info in
                        ChatAppInfoCell(info: info)
                            .listRowSeparator(.hidden)
                            .listRowInsets(.init())
                            .listRowBackground(Color(white: 0.94))
                    }
                    
                    if network.chatApps.count > 0 {
                        footerLodingView()
                    }
                }
                .listStyle(.plain)
                .background(Color(white: 0.94))
                .refreshable {
                    loadData(isRefresh: true)
                }
                //background loading indicator view
                if network.chatApps.count == 0 {
                    ProgressView()
                        .scaleEffect(1.5)
                }
                //network error notify view
                if showNetworkErrorNotify {
                    networkErrorNotifyView()
                        .shadow(color: .init(white: 0.8), radius: 8, x: 1, y: 1)
                        .transition(.opacity.animation(.easeInOut(duration: 0.5)))
                }
            }
            .navigationBarTitle("App")
            .onAppear {
                loadData()
            }
        }
    }
    
    @ViewBuilder
    func footerLodingView() -> some View {
        HStack {
            Spacer()
            if network.hasMoreData {
                ProgressView()
                    .padding(.trailing, 10)
            }
            Text(network.hasMoreData ? "loading..." : "No more data.")
            Spacer()
        }
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
        .onAppear {
            loadData()
        }
    }
    
    @ViewBuilder
    func networkErrorNotifyView() -> some View {
        VStack {
            Image(systemName: "wifi.exclamationmark")
                .foregroundColor(.white)
                .frame(width: 40, height: 30, alignment: .center)
            Text("网络似乎有问题 :(")
                .foregroundColor(.white)
        }
        .padding(20)
        .background(Color.red)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
    
    func loadData(isRefresh: Bool = false) {
        Task(priority: .background) {
            do {
                try await network.loadData(isRefresh: isRefresh)
            } catch {
                showNetworkErrorView()
            }
        }
    }
    
    func showNetworkErrorView() {
        showNetworkErrorNotify = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            showNetworkErrorNotify = false
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
