//
//  NetworkService.swift
//  App
//
//  Created by august on 2022/3/10.
//

import SwiftUI
import Combine

enum NetworkServiceError: Error {
    case invalidURL(String)
}

 class NetworkService: ObservableObject {
        
    @Published @MainActor var chatApps = [ChatAppInfo]()
    @Published @MainActor var hasMoreData = true
    internal var pageIndex = 0
    internal var request: AnyCancellable?
    
    func loadData(isRefresh: Bool = false) async throws {
        pageIndex = isRefresh ? 0 : pageIndex
        request?.cancel()
        //local file mock data
        let path = Bundle.main.path(forResource: "mockData", ofType: "txt") ?? ""
        let url = URL(fileURLWithPath: path)
        let data = try Data(contentsOf: url)
        // network data
//        let path = "https://itunes.apple.com/search?entity=software&limit=50&term=game"
//        guard let url = URL(string: path) else { throw NetworkServiceError.invalidURL(path) }
//        let (data, _) = try await URLSession.shared.data(from: url)
        let responseData = try JSONDecoder().decode(ChatAppsResponse.self, from: data)
        let infos = responseData.results
        //delay 2s to mock slowly network
        try await Task.sleep(nanoseconds: 1_000_000_000)
        await MainActor.run {
            self.chatApps.removeAll()
            let mockCount = (self.pageIndex + 1) * 10
            if infos.count > mockCount {
                self.hasMoreData = true
                self.chatApps.append(contentsOf: infos.prefix(mockCount))
            } else {
                self.chatApps.append(contentsOf: infos)
                self.hasMoreData = false
            }
            self.pageIndex += 1
        }
    }
}
