//
//  ImageLoader.swift
//  App
//
//  Created by august on 2022/3/10.
//

import UIKit

class ImageLoader {
    
    static let shared = ImageLoader()
    //
    
    func loadImage(with path: String) async -> UIImage {
        guard let url = URL(string: path) else { return UIImage() }
        return await Task(priority: .background) { () -> UIImage in
            var data = Data()
            do {
                (data, _) = try await URLSession.shared.data(from: url)
            } catch {}
            return UIImage(data: data) ?? UIImage()
        }.value
    }
}
