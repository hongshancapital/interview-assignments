//
//  Models.swift
//  App
//
//  Created by august on 2022/3/10.
//

import Foundation

struct ChatAppInfo: Codable {
    var sellerName: String
    var description: String
    var artworkUrl100: String
    var bundleId: String
}

struct ChatAppsResponse: Codable {
    var resultCount: Int
    var results: [ChatAppInfo]
}
