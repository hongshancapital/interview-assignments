//
//  ChatAppInfoCell.swift
//  App
//
//  Created by august on 2022/3/10.
//

import SwiftUI

struct ChatAppInfoCell: View {
    var info: ChatAppInfo
    @State var selected = false
    
    var body: some View {
        ZStack(alignment: .leading) {
            Color.white
                .cornerRadius(12)
            HStack(spacing: 10) {
                leftNetworkImage()
                titleAndDescriptionView()
                Spacer()
                animateHeartView()
            }
            .padding(20)
        }
        .padding(10)
        .frame(maxWidth: .infinity, minHeight: 90, alignment: .leading)
    }
    
    @ViewBuilder
    func animateHeartView() -> some View {
        Image(systemName: selected ? "heart.fill" : "heart")
            .resizable()
            .frame(width: 24, height: 24)
            .foregroundColor(.red)
            .scaleEffect(selected ? 1.1 : 1)
            .animation(.interpolatingSpring(stiffness: 100, damping: 6), value: selected)
            .onTapGesture {
                selected.toggle()
            }
    }
    
    @ViewBuilder
    func leftNetworkImage() -> some View {
        NetworkImage(imageUrl: info.artworkUrl100)
            .frame(width: 60, height: 60, alignment: .center)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color(white: 0.7), lineWidth: 0.5)
            }
    }
    
    @ViewBuilder
    func titleAndDescriptionView() -> some View {
        VStack(alignment: .leading) {
            Text(info.sellerName)
                .font(.title2)
                .lineLimit(1)
            Text(info.description)
                .font(.body)
                .lineLimit(2)
        }
    }
}

struct ChatAppInfoCell_Previews: PreviewProvider {
    static var previews: some View {
        ChatAppInfoCell(info: ChatAppInfo.init(sellerName: "artistName", description: "description", artworkUrl100: "https://is4-ssl.mzstatic.com/image/thumb/Purple126/v4/86/a6/bf/86a6bf39-bf4b-25d1-451b-28eef9c15717/source/100x100bb.jpg", bundleId: "BundleId"))
    }
}
