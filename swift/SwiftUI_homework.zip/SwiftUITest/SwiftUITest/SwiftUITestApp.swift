//
//  SwiftUITestApp.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2022/6/23.
//

import SwiftUI

@main
struct SwiftUITestApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .enableToast()
                .onTapGesture {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }
        }
    }
}
