//
//  Config.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2023/2/3.
//

import UIKit
import SwiftUI
let SCREEN_HEIGHT = UIScreen.main.bounds.height
let SCREEN_WIDTH = UIScreen.main.bounds.width
let FIR_WIDTH = UIScreen.main.bounds.size.width/375
let FIR_HEIGHT = UIScreen.main.bounds.size.height/667
let BUTTON_HEIGHTLIGHT_COLOR = Color(red: 0.42352941, green: 0.70980392, blue: 0.38039216)
let BUTTON_NORMAL_COLOR = Color(red: 0.85098039, green: 0.85098039, blue: 0.85098039)

