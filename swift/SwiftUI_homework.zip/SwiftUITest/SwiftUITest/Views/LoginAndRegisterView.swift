//
//  LoginAndRegisterView.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2023/2/2.
//

import SwiftUI
enum Type {
    case login, register
}

struct LoginAndRegisterView: View {
    //userName
    @State var userName: String = ""
    //password
    @State var password: String = ""
    //confirmPassword
    @State var confirmPassword: String = ""
    //type
    @State var type: Type = Type.login
    @State var isAction: Bool = false
    
    @State var safeAreaInsets: EdgeInsets = .init()
    
    //isCanLogin
    var isCanLogin: Bool {
        userName.count > 0 &&
        password.count > 0
    }
    var isCanRegister: Bool {
        isCanLogin &&
        confirmPassword.count > 0
    }
    
    // Verify input items
    func isValid(userName:String, password: String, confirmPassword: String) {
        isAction = false;
        if type == Type.register {
            if password.count <= 8 || confirmPassword.count <= 8 {
                showToast(content: "Password should be more than 8 digits")
                isAction = false;
            }else if(password != confirmPassword) {
                showToast(content: "The passwords entered two times are inconsistent")
                isAction = false;
            }else {
                showToast(content: "register success")
                isAction = true;
            }
        }else {
            print("login action")
            if password.count <= 8 {
                showToast(content: "Password should be more than 8 digits")
                isAction = false;
            }else {
                showToast(content: "login success")
                let time: TimeInterval = 1.0
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
                    isAction = true;
                }
            }
        }
    }
    
    var body: some View {
        let contentWidth: CGFloat = SCREEN_WIDTH - 50
        let cellHeight: CGFloat = 50
        VStack {
            Spacer().frame(width: contentWidth, height: 30, alignment: Alignment.center)
            TextField("Name", text: $userName, onCommit:{
            })
            .frame(width:contentWidth,height: cellHeight, alignment: .center)

            Divider().frame(width: contentWidth, height: 1)
            SecureField("Password", text: $password, onCommit: {

            }).frame(width:contentWidth, height: cellHeight)
            Divider().frame(width: contentWidth, height: 1)
            if type == Type.login {
                HStack {
                    Spacer()
                    NavigationLink(destination: RegistView(), label: {Text("Create Account")
                            .font(Font(UIFont.boldSystemFont(ofSize: 18)))
                            .foregroundColor(BUTTON_NORMAL_COLOR)
                            .navigationBarHidden(true)
                    })
                    .frame(alignment:Alignment.center)
                    .navigationBarTitle("login", displayMode: .inline)
                }.frame(width: contentWidth)
            }else {
                SecureField("ConfirmPassword", text: $confirmPassword, onCommit: {

                }).frame(width:contentWidth, height: cellHeight)
                Divider().frame(width: contentWidth, height: 1)
            }
            Spacer().frame(width: contentWidth, height: 30, alignment: Alignment.center)
            Button(action: {
                isValid(userName: userName, password: password, confirmPassword: confirmPassword)
            }, label: {
                 Text( type == Type.login ? "Login" : "Register")
                        .frame(width: contentWidth - 30, height: cellHeight, alignment: .center)
                        .font(Font(UIFont.boldSystemFont(ofSize: 18)))

            })
            .background((type == Type.login ? isCanLogin : isCanRegister) ? BUTTON_HEIGHTLIGHT_COLOR : BUTTON_NORMAL_COLOR)
            .cornerRadius(20)
            .disabled(type == Type.login ?  !isCanLogin : !isCanRegister)
            .foregroundColor(.white)
            .fullScreenCover(isPresented: $isAction, content: {
                PersonCenter(userName: userName).enableToast()
            })
        }.frame(width: SCREEN_WIDTH, alignment: .top)
        .contentShape(Rectangle())
        .getSafeAreaInsets($safeAreaInsets)
    }
}

struct LoginAndRegisterView_Previews: PreviewProvider {
    static var previews: some View {
            LoginAndRegisterView().background(.yellow)
    }
}

