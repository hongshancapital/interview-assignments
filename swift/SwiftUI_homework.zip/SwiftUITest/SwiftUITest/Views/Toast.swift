//
//  Toast.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2023/1/30.
//

import SwiftUI
import ExytePopupView
extension View{
    public func enableToast() -> some View{
        @AppStorage("showGlobalToast") var showGlboalToast:Bool = false;
        @AppStorage("globalToastText") var globalToastText:String = "";
        showGlboalToast = false
        globalToastText = ""
        // 调用view modifier
        return self.modifier(initToast())
    }
    
    // 显示一个Toast，传入内容
    public func showToast(content:String){
        @AppStorage("showGlobalToast") var showGlboalToast:Bool = false;
        @AppStorage("globalToastText") var globalToastText:String = "";
        
        // 修改全局变量
        showGlboalToast = true;
        globalToastText = content;
    }
    
    public func cornerRadius(radius: CGFloat,  corners: UIRectCorner ) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

struct initToast:ViewModifier{
    
    @AppStorage("showGlobalToast") var showGlboalToast:Bool = false;
    @AppStorage("globalToastText") var globalToastText:String = "";
    
    public func body(content: Content) -> some View {
        // 直接给 content 调用popup
        content.popup(isPresented: $showGlboalToast, type:.default, position: .bottom, animation: .easeOut(duration: 0), autohideIn: 1, dragToDismiss: false,closeOnTap: false,closeOnTapOutside: true,backgroundColor: .clear
        ){
            Text(globalToastText)
                .frame(width: SCREEN_WIDTH - 40, height: 80)
                .background(BUTTON_NORMAL_COLOR)
                .foregroundColor(.red)
                .cornerRadius(20.0)
        }
    }
}
