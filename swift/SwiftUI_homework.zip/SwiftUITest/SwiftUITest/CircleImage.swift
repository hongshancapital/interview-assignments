//
//  CircleImage.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2022/6/23.
//

import SwiftUI

struct CircleImage: View {
    var body: some View {
        Image("myicon")
    }
}

@available(iOS 14.0, *)
struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage()
    }
}
