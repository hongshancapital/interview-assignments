//
//  PersonCenter.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2023/2/2.
//

import SwiftUI

struct PersonCenter: View {
    @State var userName: String = ""
    @State var animated: Bool = true
    var firstLetter: String{
        String(userName[userName.startIndex])
    }
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        let contentWidth: CGFloat = SCREEN_WIDTH - 50
        VStack{
            Spacer().frame(width: SCREEN_WIDTH, height: 20).background(BUTTON_HEIGHTLIGHT_COLOR)
            VStack {
                Circle()
                    .fill(Color.gray)
                    .frame(width: 100, height: 100, alignment: .center)
                    .overlay(Text(firstLetter).font(Font(UIFont.boldSystemFont(ofSize: 80))).foregroundColor(.white))
                Text("Hello  \(userName)")
            }.frame(width: SCREEN_WIDTH, height: 280)
                .background(BUTTON_HEIGHTLIGHT_COLOR)
                .cornerRadius(radius: 30, corners: [.bottomLeft, .bottomRight])
                
            Spacer().frame(width: SCREEN_WIDTH, height: UIScreen.main.bounds.height - 300 - 190)
            Button(action: {
                showToast(content: "loginout success")
                let time: TimeInterval = 1.0
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
                    self.presentationMode.wrappedValue.dismiss()
                }
            }, label: {
                Text("loginOut")
                        .frame(width: contentWidth - 30, height: 55, alignment: .center)
                        .font(Font(UIFont.boldSystemFont(ofSize: 18)))
                        .foregroundColor(.white)
            })
            .background(BUTTON_HEIGHTLIGHT_COLOR)
            .cornerRadius(20)
        }.frame(width: SCREEN_WIDTH, height: SCREEN_HEIGHT, alignment: Alignment.top)
            .padding(SwiftUI.EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
            .background(.white)
    }
        
}

struct PersonCenter_Previews: PreviewProvider {
    static var previews: some View {
        PersonCenter()
    }
}
