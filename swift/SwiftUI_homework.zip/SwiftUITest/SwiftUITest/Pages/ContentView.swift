//
//  ContentView.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2022/6/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView(content:{
            ZStack {
                Rectangle()
                    .fill(.white)
                    .frame(alignment:.topLeading)
                VStack {
                    LoginAndRegisterView(type: Type.login)
                    Spacer()
                }
            }
            .frame(alignment:.topLeading)
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().frame(width: SCREEN_WIDTH, height: SCREEN_HEIGHT, alignment: .top)
    }
}
