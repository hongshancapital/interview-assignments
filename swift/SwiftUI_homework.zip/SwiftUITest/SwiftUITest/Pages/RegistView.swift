//
//  RegistView.swift
//  SwiftUITest
//
//  Created by zhengjun1 on 2023/2/2.
//

import SwiftUI

struct RegistView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        ZStack {
            Rectangle()
                .fill(.white)
                .frame(alignment:.topLeading)
            VStack {
                LoginAndRegisterView(type: Type.register)
                    .navigationBarHidden(false)
                    .navigationBarTitle("Create Account", displayMode: .inline)
                Spacer()
            }
        }
        .frame(alignment:.topLeading)
    }
}

struct RegistView_Previews: PreviewProvider {
    static var previews: some View {
        RegistView()
    }
}
