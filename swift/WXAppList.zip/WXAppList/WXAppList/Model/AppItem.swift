//
//  AppItem.swift
//  WXAppList
//
//  Created by wuxi on 2023/1/9.
//

import Foundation

struct AppItem: Decodable, Identifiable {
    
    var id = UUID()
    var title: String
    var desc: String
    var photoUrl: String
    var collected: Bool = false
    
    enum CodingKeys: CodingKey {
        case sellerName
        case trackCensoredName
        case description
        case artworkUrl60
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let sellname: String = try container.decode(String.self, forKey: .sellerName)
        let trackname: String = try container.decode(String.self, forKey: .trackCensoredName)
        self.title = "\(sellname) \(trackname)"
        self.desc = try container.decode(String.self, forKey: .description)
        self.photoUrl = try container.decode(String.self, forKey: .artworkUrl60)
    }
}



struct PaginationResponse: Decodable {
    var data: [AppItem]
    var pageIndex: Int = 0
    var isEnd: Bool = false
    
    enum CodingKeys: CodingKey {
        case results
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.data = try container.decode([AppItem].self, forKey: .results)
    }
}
