//
//  WXAppListApp.swift
//  WXAppList
//
//  Created by wuxi on 2023/1/9.
//

import SwiftUI

@main
struct WXAppListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
