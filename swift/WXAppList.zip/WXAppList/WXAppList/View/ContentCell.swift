//
//  ContentCell.swift
//  SwiftUIList
//
//  Created by wuxi on 2023/1/9.
//

import Foundation
import SwiftUI

extension String {
    var url: URL? {
        return URL(string: self)
    }
}

struct ContentCell: View {

    @State var item: AppItem
    
    private var photoView: some View {
        AsyncImage(url: item.photoUrl.url) { phase in
            if let image = phase.image {
                image // Displays the loaded image.
            } else if phase.error != nil {
                Color.gray
            } else {
                ProgressView()
            }
        }
        .frame(width: 50, height: 50)
        .cornerRadius(6)
    }
    
    var body: some View {
        Group {
            HStack {
                photoView
                VStack(alignment: .leading) {
                    Text(item.title)
                        .font(.system(size: 16, weight: .bold))
                        .lineLimit(1)
//                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 2, trailing: 0))
                        .frame(alignment: .leading)
                    Text(item.desc)
                        .font(.system(size: 14, weight: .light))
                        .lineLimit(2)
                        .frame(alignment: .leading)
                }
                Spacer()
                Button(action: {
                    self.item.collected = !item.collected
                }) {
                    Image(item.collected ? "like_fill" : "like")
                }
                .frame(width: 40, height: 40)
                .padding(EdgeInsets(top: 0, leading: 2, bottom: 0, trailing: 4))
            }
        }
        .frame(height: 60)
        .listRowBackground(
            RoundedRectangle(cornerRadius: 10).foregroundColor(Color.white)
                .padding(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
        )
        .listRowSeparator(.hidden)
    }
    
    
}

struct WXImageView: View {
    
    let url: URL?
    @State private var img: UIImage? = nil
    
    var body: some View {
        guard let img = img else {
            return AnyView(ProgressView()
                .progressViewStyle(.circular)
            )
            .onAppear(perform: fetchData)
        }
        return AnyView(
            Image(uiImage: img)
        )
        .onAppear(perform: fetchData)
        
    }
    
    private func fetchData() {
        guard let url = url, img == nil else {
            return
        }
        URLSession.shared.dataTask(with: URLRequest(url: url)) { data, response, error in
            guard let data = data,
                  let img = UIImage(data: data) else {
                return
            }
//            print("img - \(img)")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                self.img = img
            })
            
        }.resume()
    }
}
