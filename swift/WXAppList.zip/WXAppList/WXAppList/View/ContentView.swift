//
//  ContentView.swift
//  WXAppList
//
//  Created by wuxi on 2023/1/9.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var vm = ListViewModel()
    
    private var footer: some View {
        Group {
            if vm.noMore {
                Text("No More Data.")
            }
            else if vm.loadingMore {
                HStack {
                    Text("Loading...")
                    ProgressView()
                }
            } else {
                Text("")
            }
        }
        .frame(maxWidth: .infinity, alignment: .center)
        .foregroundColor(Color.gray)
        .listRowBackground(Rectangle().foregroundColor(Color.clear))
        .onAppear {
            vm.fetchData(loadMore: true)
        }
    }
    
    private var contentView: some View {
        Group {
            if vm.data.isEmpty {
                ProgressView()
                    .onAppear {
                        vm.fetchData()
                    }
            } else {
                List {
                    ForEach(vm.data) { ContentCell(item: $0) }
                    footer
                }
                .frame(maxWidth: .infinity, alignment: .top)
                .refreshable {
                    vm.fetchData()
                }
            }
        }
        .overlay {
            if let err = vm.error {
                Text("\(err.localizedDescription)")
                    .frame(width: 100, height: 40)
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(6)
            }
        }
    }
    
    var body: some View {
        NavigationView {
            contentView.navigationTitle("App")
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
