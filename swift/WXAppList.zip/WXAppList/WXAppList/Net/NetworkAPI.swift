//
//  NetworkAPI.swift
//  WXAppList
//
//  Created by wuxi on 2023/1/9.
//

import Foundation
import Combine

enum APIErrorType {
    case netFail
    case parseFail
    case unkown
}

struct APIError: LocalizedError {
    
    let type: APIErrorType
    var internalError: Error?
    
    var errorDescription: String? {
        return "\(type)-\(internalError?.localizedDescription ?? "")"
    }
}

struct NetWorkAPI {
    
    static func fetchData(url: URL) -> AnyPublisher<PaginationResponse, APIError> {
        let publisher = URLSession.shared.dataTaskPublisher(for: url)
        return publisher.tryMap { (data: Data, response: URLResponse) in
            guard let response = response as? HTTPURLResponse,
                  response.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }
            return data
        }
        .delay(for: 2, scheduler: RunLoop.main)
        .decode(type: PaginationResponse.self, decoder: JSONDecoder())
        .mapError({ $0 is DecodingError ?
            APIError(type: .parseFail, internalError: $0) :
            APIError(type: .netFail, internalError: $0)
        })
        .eraseToAnyPublisher()
    }
}
