//
//  ListViewModel.swift
//  WXAppList
//
//  Created by wuxi on 2023/1/9.
//

import Foundation
import Combine

final class ListViewModel: ObservableObject {
    
    @Published private(set) var data: [AppItem] = []
    @Published private(set) var error: APIError? = nil
    @Published private(set) var noMore: Bool = false
    @Published private(set) var currentPage: Int = 0
    @Published private(set) var loading: Bool = false
    @Published private(set) var loadingMore: Bool = false
    
    private var publishers: [AnyCancellable] = []
    
    
    func fetchData(loadMore: Bool = false) {
        publishers.forEach({ $0.cancel() })
        publishers.removeAll()
        if loadMore && noMore { return }
        loadingMore = loadMore
        loading = !loadMore
        NetWorkAPI.fetchData(url: URL(string: "https://itunes.apple.com/search?entity=software&limit=50&term=chat")!)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.loading = false
                self?.loadingMore = false
                print("finish fetch...")
                switch completion {
                case .finished:
                    break
                case .failure(let err):
                    print("err: \(err.localizedDescription)")
                    self?.error = err
                }
            } receiveValue: { [weak self] response in
                guard let self = self else {
                    return
                }
                print("receive value... ")
                if !loadMore {
                    self.data = Array(response.data.prefix(10))
                    self.currentPage = 0
                    self.noMore = false
                } else {
                    let limit: Int = 10
                    let startIndex = self.currentPage * limit
                    let endIndex = (self.currentPage + 1) * limit
                    self.currentPage += 1
                    guard startIndex < endIndex, response.data.count > endIndex else {
                        self.noMore = true
                        return
                    }
                    let slice: [AppItem] = Array(response.data[startIndex..<endIndex])
                    self.data = self.data + slice
                }
            }
            .store(in: &publishers)

    }
}
