//
//  XCBaseModel.swift
//  XCWorks
//
//  Created by 张兴程 on 2022/12/26.
//

import UIKit

///所有Model的基类
class XCBaseModel: NSObject {

    public var xcCellHeigh : CGFloat?

}
