//
//  UserManager.swift
//  Login
//
//  Created by 李建平 on 2021/8/19.
//

import Foundation

struct UserInfo {
    public var username: String?
    public var password: String?
}


class UserManager: NSObject {
    static let shared = UserManager()
    
    public var userInfo: UserInfo?
    private var users = [String: Any]()
    
    private override init() {
        
    }
    
    override class func copy() -> Any {
        return self
    }

    override class func mutableCopy() -> Any {
        return self
    }
    
    // 模拟网络请求，将创建的内容临时存到 内存中，当次启动有效
    func requestCreatAccount(name: String, pwd: String, handle: (Bool)->(Void)) {
        if (nil != users[name]) {
            handle(false)
            return
        }
        
        users[name] = pwd
        
        handle(true)
    }
    
    // 模拟网络请求，登录页面，从临时内存中存储的账户验证是否存在
    func requestLogin(name: String, pwd: String, handle: (String, String)->(Void)) {
        if (users[name] != nil) {
            self.userInfo = UserInfo()
            self.userInfo?.username = name
            self.userInfo?.password = pwd
            
            handle(name, pwd)
        } else {
            handle("", "")
        }
    }
    
    // 退出登录，将当前登录的直接推出
    func requestLogout(handle: (Bool)->(Void)) {
        self.userInfo = nil
        
        handle(true)
    }
}
