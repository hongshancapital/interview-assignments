//
//  LoginApp.swift
//  Login
//
//  Created by 李建平 on 2021/8/19.
//

import SwiftUI

@main
struct LoginApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
