//
//  CreatAccountView.swift
//  Login
//
//  Created by 李建平 on 2021/8/19.
//

import SwiftUI

struct CreatAccountView: View {
    
    @State private var username = ""
    @State private var password = ""
    @State private var repeatpwd = ""
    @State var btnEnable:Bool = false
    @State var tips:String = ""
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        VStack() {
            // 第一个 用户名
            TextField("Name", text: $username)
                .font(Font.system(size: 15))
                .padding(.leading, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            // 分割线
            Divider()
                .padding(.bottom, 10)
    
            // 第二个 密码框
            SecureField("Password", text: $password)
                .font(Font.system(size: 15))
                .padding(.leading, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            // 分割线
            Divider()
                .padding(.bottom, 10)
            
            // 第三个 密码
            SecureField("Repeat Password", text: $repeatpwd)
                .font(Font.system(size: 15))
                .padding(.leading, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            // 分割线
            Divider()
                .padding(.bottom, 40)
            
            // 提交按钮
            Button.init(action: {
                if (self.username.count < 1 && self.password.count < 8 && self.repeatpwd.count < 8) {
                    return
                }
                
                if (!self.password.elementsEqual(self.repeatpwd)) {
                    self.tips = "Password error!"
                    
                    return
                }
                
                // 状态转换
                UserManager.shared.requestCreatAccount(name: self.username, pwd: self.password) { flag in
                    if flag {
                        self.presentationMode.wrappedValue.dismiss()
                    } else {
                        self.tips = "Creat account error!"
                    }
                }
            }, label: {
                Text("Creat Account")
                    .foregroundColor(.white)
            })
            .frame(width: 200, height: 10, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .padding()
            .background(self.username.count > 0 && self.password.count >= 8 && self.repeatpwd.count >= 8 ? Color.green : Color.gray.opacity(3.0))
            .cornerRadius(8)
            
            Text("\(self.tips)")
                .foregroundColor(.red)
                .font(.system(size: 15))
                .padding(.top, 100)
            
        }
        .padding(EdgeInsets.init(top: 0, leading: 10, bottom: 80, trailing: 10))
        .onTapGesture {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        }
        .navigationBarHidden(true)
        .statusBar(hidden: true)
    }
}

struct CreatAccountView_Previews: PreviewProvider {
    static var previews: some View {
        CreatAccountView()
    }
}
