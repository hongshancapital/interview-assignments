//
//  ContentView.swift
//  Login
//
//  Created by 李建平 on 2021/8/19.
//

import SwiftUI

struct LoginView: View {
    @State var username = ""
    @State var password = ""
    @State var btnEnable:Int? = 0
    @State var tips:String = ""
    
    var body: some View {
        NavigationView {
            VStack() {
                // 第一个 用户名
                TextField.init("Name", text: $username)
                    .font(Font.system(size: 15))
                    .padding(.leading, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                
                // 分割线
                Divider()
                    .padding(.bottom, 10)
                    
                // 第二个 密码
                SecureField("Repeat Password", text: $password)
                    .font(Font.system(size: 15))
                    .padding(.leading, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                
                // 分割线
                Divider()
                    .padding(.bottom, 0)
                
                HStack() {
                    Spacer()
                    
                    NavigationLink(
                        destination: CreatAccountView(),
                        label: {
                            Text("Creat Account")
                                .foregroundColor(.gray.opacity(0.5))
                                .font(.system(size: 15))
                        })
                }
                .padding(.bottom, 40)
                
                NavigationLink(
                    destination: HomeView(),
                    tag: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/,
                    selection: $btnEnable,
                    label: {
                        Button.init(action: {
                            // 做用户名和密码的校验 如果是正确的 就登录
                            UserManager.shared.requestLogin(name: self.username, pwd: self.password) { name, pwd in
                                if(name.count > 0 && pwd.count > 0) {
                                    self.btnEnable = 1
                                    self.tips = ""
                                    self.username = ""
                                    self.password = ""
                                } else {
                                    self.tips = "Name or password error!"
                                }
                            }
                        }, label: {
                            Text("Login")
                                .foregroundColor(.white)
                                .frame(width: 230, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        })
                        .frame(width: 230, height: 40, alignment: .center)
                            
                    })
                    .background(self.username.count > 0 && self.password.count >= 8 ? Color.green : Color.gray.opacity(3.0))
                    .cornerRadius(8)
                
                Text("\(self.tips)")
                    .foregroundColor(.red)
                    .font(.system(size: 15))
                    .padding(.top, 100)
            }
            .padding(EdgeInsets.init(top: 0, leading: 10, bottom: 150, trailing: 10))
            .statusBar(hidden: true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
