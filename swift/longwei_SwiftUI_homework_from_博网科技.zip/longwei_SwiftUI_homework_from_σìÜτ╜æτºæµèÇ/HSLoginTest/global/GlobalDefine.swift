//
//  globaldefine.swift
//  HSLoginTest
//
//  Created by 伟龙 on 2021/3/10.
//

import Foundation
import  SwiftUI
internal  let  loginandresgiteredgeInset:EdgeInsets = EdgeInsets.init(top: 4, leading: 16, bottom: 8, trailing: 16)
internal  let  backgrayColor = Color(red: 244/255.0, green: 244/255.0, blue: 244/255.0)

