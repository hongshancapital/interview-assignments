//
//  ContentView.swift
//  demo
//
//  Created by msz on 2022/3/13.
//

import SwiftUI
import BBSwiftUIKit

/// 列表
//struct ContentView: View {
//    @ObservedObject var dataCenter = DataProvider()
//    var body: some View {
//        NavigationView {
//            List {
//                ForEach(dataCenter.dataArray) { item in
//                    ListItemRow(itemModel: item)
//                }
//            }
//            .navigationBarTitle("App")
//            .onAppear(perform: dataCenter.request)
//        }
//    }
//}

struct ContentView: View {
    @State var isRefreshing: Bool = false
    @State var isLoadingMore: Bool = false
    @State var isReloadData: Bool = false
    
    @ObservedObject var dataCenter = DataProvider()
    
    var body: some View {
        NavigationView {
            BBTableView(dataCenter.dataArray) { item in
                ListItemRow(itemModel: item)
                    .padding(10)
                    .background(Color(uiColor: UIColor(red: CGFloat(244)/CGFloat(255),
                                                       green: CGFloat(244)/CGFloat(255),
                                                       blue: CGFloat(247)/CGFloat(255),
                                                       alpha: 1)))
            }
            .bb_reloadData($isReloadData)
            .bb_setupRefreshControl({ refreshControl in
                refreshControl.tintColor = .blue
                refreshControl.attributedTitle = NSAttributedString(string: "Loading...", attributes: [.font: UIFont.systemFont(ofSize: 15), .foregroundColor: UIColor.blue])
            })
            .bb_pullDownToRefresh(isRefreshing: $isRefreshing, refresh: {
                print("bb_pullDownToRefresh");
                dataCenter.refreshRequest { isError in
                    if isError == false {
                        self.isRefreshing = false
                    }
                }
            })
            .bb_pullUpToLoadMore(bottomSpace: 40, loadMore: {
                print("bb_pullUpToLoadMore");
                if self.isLoadingMore == false {
                    self.isLoadingMore = true
                    dataCenter.loadMoreRequest { isError in
                        self.isLoadingMore = false;
                    }
                }
            })
            .onAppear(perform: {
                dataCenter.refreshRequest()
            })
            .navigationTitle("App")            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
