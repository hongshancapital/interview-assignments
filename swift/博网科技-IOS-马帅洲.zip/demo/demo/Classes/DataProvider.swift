//
//  DataProvider.swift
//  demo
//
//  Created by msz on 2022/3/13.
//

import Foundation
import Alamofire
import MGSwiftCandy

/// 请求接口数据类
final class DataProvider: ObservableObject {
    var page = 1;
    var isFull: Bool {
        get {
            return page >= 10
        }
    }
    
    @Published var dataArray: [ListItemModel] = []
    
    func refreshRequest(complete:((_ isError: Bool)->Void)? = nil) {
        page = 1
        request { isError in
            complete?(isError)
        }
    }
    
    func loadMoreRequest(complete:((_ isError: Bool)->Void)? = nil) {
        if isFull == true {
            return
        }
        
        page += 1
        weak var weakSelf = self
        request { isError in
            guard let strongSelf = weakSelf else {
                return
            }
            
            if isError {
                strongSelf.page -= 1
            }
            
            complete?(isError)
        }
    }
    
    private func request(complete:((_ isError: Bool)->Void)? = nil) {
        let url = "https://itunes.apple.com/search?entity=software&limit=12&term=chat"
        let param: Parameters = [:]
        AF.request(URL(string: url)!, method: .get, parameters: param)
            .responseString { (responses) in
                let strData:String = responses.value ?? ""
                if strData.count <= 0 {
                    complete?(true)
                    return;
                }
                
                let data = ListData.decode(from: strData);
                guard let data = data, data.resultCount ?? 0 > 0 else {
                    complete?(true)
                    return;
                }
                guard let results = data.results, results.count > 0 else {
                    complete?(true)
                    return
                }
                
                var dataSource: [ListItemModel] = [];
                dataSource.append(contentsOf: self.dataArray);
                dataSource.append(contentsOf: results);
                self.dataArray = dataSource;
                
                print(strData)
                
                complete?(false)
            }
    }
    
}
