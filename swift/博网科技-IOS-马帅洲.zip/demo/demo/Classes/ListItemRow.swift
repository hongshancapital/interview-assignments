//
//  ListItemRow.swift
//  demo
//
//  Created by msz on 2022/3/13.
//

import SwiftUI

/// 列表项视图(cell)
struct ListItemRow: View {
    var itemModel: ListItemModel
    @State var image = Image("fabulous_no")
    var body: some View {
        HStack {
            if let artworkUrl60 = itemModel.artworkUrl60, artworkUrl60.count > 0 {
                WebImageView(imageUrl: artworkUrl60)
                    .frame(width: 44, height: 44)
                    .cornerRadius(7)
                    .padding(.leading, 10)
            }

            VStack(alignment: .leading) {
                Text(itemModel.sellerName ?? "")
                    .font(.headline)
                    .padding(.top, 10)
                    .lineLimit(1)
                
                Spacer()
                
                Text(itemModel.description ?? "")
                    .foregroundColor(.secondary)
                    .padding(.bottom, 10)
                    .lineLimit(2)
            }
            .padding(.leading, 10)
            
            Spacer()
            
            image.resizable()
                .frame(width: 24, height: 24, alignment: .center)
                .onTapGesture {
                    itemModel.fabulous = !itemModel.fabulous
                    image = Image(itemModel.fabulous ? "fabulous" : "fabulous_no")
                }
                .clipped()
                .padding(.trailing, 10)
        }
        .background(.white)
    }
}
