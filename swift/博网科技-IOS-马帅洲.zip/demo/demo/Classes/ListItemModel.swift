//
//  ListItemModel.swift
//  demo
//
//  Created by msz on 2022/3/13.
//

import Foundation

/// 使用的Model
class ListData: Codable {
    var resultCount: Int?
    var results: [ListItemModel]?
}

class ListItemModel: Codable, Equatable, Identifiable {
    public var artworkUrl60: String?
    public var sellerName: String?
    public var description: String?
    public var isGameCenterEnabled: Bool?
    
    static func == (lhs: ListItemModel, rhs: ListItemModel) -> Bool {
        return lhs.artworkUrl60 == rhs.artworkUrl60 &&
                lhs.sellerName == rhs.sellerName &&
                lhs.description == rhs.description &&
                lhs.isGameCenterEnabled == rhs.isGameCenterEnabled
    }
    
    var fabulous: Bool {
        get {
            if let isGameCenterEnabled = self.isGameCenterEnabled, isGameCenterEnabled == true {
                return true
            }
            
            return false
        }
        set {
            self.isGameCenterEnabled = newValue
        }
    }
}
