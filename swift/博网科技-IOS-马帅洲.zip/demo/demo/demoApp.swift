//
//  demoApp.swift
//  demo
//
//  Created by msz on 2022/3/13.
//

import SwiftUI

@main
struct demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
