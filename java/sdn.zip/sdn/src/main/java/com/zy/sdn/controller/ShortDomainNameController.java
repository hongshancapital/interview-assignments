package com.zy.sdn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zy.sdn.common.Result;
import com.zy.sdn.service.ShortDomainNameService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/sdn")
@Api(value = "短域名Controller",tags={"短域名相关接口"})
public class ShortDomainNameController {

	@Autowired
	private ShortDomainNameService shortDomainNameService;

	@ApiOperation(value = "根据短链接获取长链接")
	@GetMapping(value = "/getLongUrl/{shortUrl}")
	public Result getShortUrl(
			@ApiParam(value = "短链接,urlEncode后的结果", required = true) @PathVariable(required = true) String shortUrl) {
		String res = shortDomainNameService.getLongUrlByShortUrl(shortUrl);
		return Result.succ(res);
	}

	@ApiOperation(value = "根据长链接获取短链接")
	@GetMapping(value = "/getShortUrl/{longUrl}")
	public Result getLongUrl(@ApiParam(value = "长链接,urlEncode后的结果", required = true) @PathVariable(required = true) String longUrl) {
		String res = shortDomainNameService.getShortUrlByLongUrl(longUrl);
		return Result.succ(res);
	}

}
