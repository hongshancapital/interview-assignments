package com.zy.sdn.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @ClassName Result
 * @Description 成功返回data,失败无data
 * @author zhanyi
 * @Date 2021年10月9日 上午10:08:07
 * @version 1.0.0
 * @param <T>
 */
@ApiModel("通用结果类型") 
public class Result {	
	
	@ApiModelProperty(value="状态码")
	private Integer status;
	
	@ApiModelProperty(value="备注说明")
    private String desc;
    
	@ApiModelProperty(value="数据内容")
    private Object data;
    
    private static Integer DEFAULT_SUCCESS_STATUS=200;
    /**
     * @Description 成功的写法
     * @param data
     * @return
     */
	public static Result succ(Object data){
        Result result=new Result();
        result.setStatus(DEFAULT_SUCCESS_STATUS);
        result.setData(data);
        return result;
    }

    /**
     * @Description 失败的写法
     * @param status
     * @param desc
     * @return
     */
    public static Result fail(Integer status,String desc){
        Result result=new Result();
        result.setStatus(status);
        result.setDesc(desc);
        return result;
    }

    public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}	

}