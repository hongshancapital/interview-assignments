package com.zy.sdn.common.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.zy.sdn.common.Result;

/**
 * @ClassName GlobalExceptionHandle
 * @Description 全局统一异常处理
 * @author zhanyi
 * @Date 2021年10月9日 上午8:30:28
 * @version 1.0.0
 */
@RestControllerAdvice
public class GlobalExceptionHandle {
	
	private static final Logger logger=LogManager.getLogger(GlobalExceptionHandle.class);
	
	public static Integer DEFAULT_ERROR_CODE = 500;

	public static String DEFAULT_ERROR_MESSAGE = "系统繁忙，请联系管理员";

	@ExceptionHandler(value = BusinessException.class)
	public Result handle(BusinessException e) {
		logger.error(e);		
		Result res = Result.fail(e.getErrorCode(), e.getErrorMessage());
		return res;
	}

	@ExceptionHandler(value = Exception.class)
	public Result handle(Exception e) {
		logger.error(e);		
		Result res = Result.fail(DEFAULT_ERROR_CODE, DEFAULT_ERROR_MESSAGE);
		return res;
	}
}
