package com.zy.sdn.common.exception;

public enum ErrorCodeEnum {

	/**
	 * @Field @NODATA : 数据不存在
	 */
	NODATA(10000,"数据不存在"),
	
	/**
	 * @Field @URLFAIL : 地址生产失败
	 */
	URLFAIL(10001,"地址生成失败");

	private Integer errorCode;

	private String errorMessage;

	ErrorCodeEnum(Integer errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public Integer getErrorCode() {
		return this.errorCode;
	}

	public String getErrorMessage() {
		return this.errorMessage;
	}
}
