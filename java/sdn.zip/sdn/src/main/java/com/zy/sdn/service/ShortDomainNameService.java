package com.zy.sdn.service;

public interface ShortDomainNameService {

	/**
	 * @Description 根据长链接查询短链接
	 * @param longUrl
	 * @return
	 */
	public String getShortUrlByLongUrl(String longUrl);

	/**
	 * @Description 根据短链接查询长链接
	 * @param longUrl
	 * @return
	 */
	public String getLongUrlByShortUrl(String shortUrl);

}
