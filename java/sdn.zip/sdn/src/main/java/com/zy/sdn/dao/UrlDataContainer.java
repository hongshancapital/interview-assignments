package com.zy.sdn.dao;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * @ClassName UrlDataContainer
 * @Description 数据存储的结构，
 * 为了快速的查找数据，这里使用了2个hashMap,其中一个以短连接为key，长链接为value，另一个相反，空间换时间。
 * 为防止内存溢出，使用LRU方式淘汰一批数据，LRU基于LinkedHashMap实现
 * 由于个人时间关系，2个map之间并没有所有的put clear等操作都做同步。
 * @author zhanyi
 * @Date 2021年10月9日 下午4:12:53
 * @version 1.0.0
 */
public class UrlDataContainer {

	private HashMap<String, String> longUrlDataMap = new HashMap<String, String>(4048);

	private LRULinkedHashMap<String, String> shortUrlDataMap = new LRULinkedHashMap<String, String>(4048,
			longUrlDataMap);
	
	public String getLongUrlByShortUrl(String shortUrl) {
		return shortUrlDataMap.get(shortUrl);
	}

	public String getShortUrlByLongUrl(String longUrl) {
		return longUrlDataMap.get(longUrl);
	}

	public Boolean addUrl(String shortUrl, String longUrl) {
		if (longUrlDataMap.containsKey(longUrl) || shortUrlDataMap.containsKey(shortUrl)) {
			return false;
		}
		longUrlDataMap.put(longUrl, shortUrl);
		shortUrlDataMap.put(shortUrl, longUrl);
		return true;
	}
	
	public void clear() {
		longUrlDataMap.clear();
		shortUrlDataMap.clear();
	}

	private class LRULinkedHashMap<K, V> extends LinkedHashMap<K, V> {

		private static final long serialVersionUID = -7971438719252105001L;

		private HashMap<V, K> reverseHashMap = new HashMap<V, K>();

		/**
		 * 总容量
		 */
		private int capacity;

		public LRULinkedHashMap(int capacity, HashMap<V, K> reverseMap) {
			super(16, 0.75f, true);
			this.capacity = capacity;
			this.reverseHashMap = reverseMap;
		}

		@Override
		public boolean removeEldestEntry(Map.Entry<K, V> eldest) {
			if (size() > capacity) {
				reverseHashMap.remove(eldest.getValue());
				return true;
			}
			return false;
		}

	}

}
