package com.zy.sdn.common.exception;

public class BusinessException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public static Integer DEFAULT_ERROR_CODE = 500;

	public static String DEFAULT_ERROR_MESSAGE = "unknown error";

	private Integer errorCode;

	private String errorMessage;

	public BusinessException() {
		this.setErrorCode(DEFAULT_ERROR_CODE);
		this.setErrorMessage(DEFAULT_ERROR_MESSAGE);
	}
	
	public BusinessException(String errorMessage) {
		this.setErrorCode(DEFAULT_ERROR_CODE);
		this.setErrorMessage(errorMessage);
	}
	
	
	public BusinessException(Integer errorCode,String errorMessage) {
		this.setErrorCode(errorCode);
		this.setErrorMessage(errorMessage);
	}
	
	public BusinessException(ErrorCodeEnum errorCodeEnum) {
		this.setErrorCode(errorCodeEnum.getErrorCode());
		this.setErrorMessage(errorCodeEnum.getErrorMessage());
	}


	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	

}
