package com.zy.sdn.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.zy.sdn.common.exception.BusinessException;
import com.zy.sdn.common.exception.ErrorCodeEnum;
import com.zy.sdn.dao.UrlDataMapper;
import com.zy.sdn.service.ShortDomainNameService;

/**
 * @ClassName ShortDomainNameServiceImpl
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author zhanyi
 * @Date 2021年10月15日 下午6:41:30
 * @version 1.0.0
 */
/**
 * @ClassName ShortDomainNameServiceImpl
 * @Description 短域名服务实现类
 * @author zhanyi
 * @Date 2021年10月15日 下午6:41:32
 * @version 1.0.0
 */
@Service
public class ShortDomainNameServiceImpl implements ShortDomainNameService {

	private static final Logger logger = LogManager.getLogger(ShortDomainNameServiceImpl.class);

	/**
	 * @Field @urlPrefix : 短域名的前缀
	 */
	@Value("${urlPrefix}")
	private String urlPrefix;

	/**
	 * @Field @MAX_SHORT_URL_LENGTH : 最大短url长度
	 */
	private static Integer MAX_SHORT_URL_LENGTH = 8;

	/**
	 * @Field @URL_CODE : url编码
	 */
	private static String URL_CODE = "UTF-8";

	/**
	 * @Field @REG_MATCH_ALL : 匹配所有的后缀
	 */
	private static String REG_MATCH_ALL = "(.*)";

	@Override
	public String getShortUrlByLongUrl(String longUrl) {
		String shortUrl = UrlDataMapper.getShortUrlByLongUrl(longUrl);
		if (StringUtils.isEmpty(shortUrl)) {
			shortUrl = buildShortUrl();
			// 存储新的短连接
			UrlDataMapper.addUrlData(shortUrl, longUrl);
			logger.info("生成的shortUrl为" + shortUrl);
		}
		// 进行转码		
		String url = encodeUrl(urlPrefix + shortUrl); 
		return url;
	}

	@Override
	public String getLongUrlByShortUrl(String shortUrl) {
		String longUrl = UrlDataMapper.getLongUrlByShortUrl(removePrefix(shortUrl));
		if (StringUtils.isEmpty(longUrl)) {
			throw new BusinessException(ErrorCodeEnum.NODATA);
		}
		return longUrl;
	}

	/**
	 * @Description 使用一个自增长的数字表示域名,方法简单，但存在一定安全风险，域名容易被猜出来.长度超过8则重置
	 * @return
	 */
	private String buildShortUrl() {
		String shortUrl = UrlDataMapper.getIncreaseKey().toString();
		if (shortUrl.length() >= MAX_SHORT_URL_LENGTH) {
			UrlDataMapper.resetKey();
			shortUrl = UrlDataMapper.getIncreaseKey().toString();
		}
		return shortUrl;
	}

	/**
	 * @Description 去掉短域名的公共前缀
	 * @param shortUrl
	 * @return
	 */
	private String removePrefix(String shortUrl) {
		String urlPrefixDecode = encodeUrl(urlPrefix);
		if (!Strings.isEmpty(shortUrl) && shortUrl.matches(urlPrefixDecode + REG_MATCH_ALL)) {
			return shortUrl.substring(urlPrefixDecode.length());
		}
		throw new BusinessException(ErrorCodeEnum.NODATA);
	}

	
	private String encodeUrl(String url) {		
		try {
			url = URLEncoder.encode(url, URL_CODE);
			return url;
		} catch (UnsupportedEncodingException e) {
			logger.error("urlencode失败", e);
			throw new BusinessException(ErrorCodeEnum.URLFAIL);
		}		
	}
}
