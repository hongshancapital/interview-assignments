package com.zy.sdn.dao;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @ClassName UrlDataMapper
 * @Description 使用AtomicInteger类型表示数据库自增长的主键，使用UrlDataContainer存储数据
 * @author zhanyi
 * @Date 2021年10月9日 上午11:15:28
 * @version 1.0.0
 */
public class UrlDataMapper {

	private static UrlDataContainer dataContainer = new UrlDataContainer();

	private static AtomicInteger key = new AtomicInteger(0);

	public static void addUrlData(String shortUrl, String longUrl) {
		dataContainer.addUrl(shortUrl, longUrl);
	}

	public static String getShortUrlByLongUrl(String longUrl) {
		return dataContainer.getShortUrlByLongUrl(longUrl);

	}

	public static String getLongUrlByShortUrl(String shortUrl) {
		return dataContainer.getLongUrlByShortUrl(shortUrl);

	}

	public static Integer getIncreaseKey() {
		return key.addAndGet(1);
	}
	
	public static void resetKey() {
		key = new AtomicInteger(0);
	}
	
	public static void deleteAllUrl() {
		key = new AtomicInteger(0);
		dataContainer.clear();
	}

}
