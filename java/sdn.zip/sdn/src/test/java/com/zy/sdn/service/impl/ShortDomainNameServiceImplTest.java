package com.zy.sdn.service.impl;

import org.apache.logging.log4j.util.Strings;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zy.sdn.common.exception.BusinessException;
import com.zy.sdn.dao.UrlDataMapper;

/**
 * @ClassName ShortDomainNameServiceImplTest
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author zhanyi
 * @Date 2021年10月19日 下午5:14:38
 * @version 1.0.0
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class ShortDomainNameServiceImplTest {

	@Autowired
	private ShortDomainNameServiceImpl shortDomainNameService;

	@Value("${urlPrefix}")
	private String urlPrefix;

	private static String INIT_SHORT_URL = "0";

	private static String SHORT_URL_1 = "www.xxx.com%2F0";

	private static String SHORT_URL_2 = "www.xxx.com%2F1";

	private static String SHORT_URL_3 = "www.xxx.com%2F2";

	private static String ERROR_SHORT_URL = "www.yyy.com%2F0";

	private static String LONG_URL_1 = "www.zy.com%2Ftest%2Faabbccdd";

	private static String LONG_URL_2 = "www.zy.com%2Ftest%2Faabbccddeeff";

	private static String LONG_URL_3 = "www.zy.com%2Ftest%2Faabbccddeeffgg";

	@Rule
	public final ExpectedException expectedException = ExpectedException.none();

	/**
	 * @Description 初始化数据
	 */
	@Before
	public void before() {
		UrlDataMapper.addUrlData(INIT_SHORT_URL, LONG_URL_1);
	}

	/**
	 * @Description 清除之前插入的数据
	 */
	@After
	public void after() {
		UrlDataMapper.deleteAllUrl();
	}

	/**
	 * @Description 验证自增长逻辑
	 */
	@Test
	public void testGetShortUrlByLongUrl1() {
		Assert.assertEquals(shortDomainNameService.getShortUrlByLongUrl(LONG_URL_1), SHORT_URL_1);
	}

	/**
	 * @Description 验证自增长逻辑
	 */
	@Test
	public void testGetShortUrlByLongUrl2() {
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_1);
		Assert.assertEquals(shortDomainNameService.getShortUrlByLongUrl(LONG_URL_2), SHORT_URL_2);
	}

	/**
	 * @Description 验证自增长逻辑
	 */
	@Test
	public void testGetShortUrlByLongUrl3() {
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_1);
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_2);
		Assert.assertEquals(shortDomainNameService.getShortUrlByLongUrl(LONG_URL_3), SHORT_URL_3);
	}

	/**
	 * @Description 验证自存储逻辑
	 */
	@Test
	public void testGetShortUrlByLongUrl4() {
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_1);
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_2);
		shortDomainNameService.getShortUrlByLongUrl(LONG_URL_3);
		Assert.assertEquals(shortDomainNameService.getShortUrlByLongUrl(LONG_URL_1), SHORT_URL_1);
	}

	/**
	 * @Description 验证取不存在的短连接逻辑
	 */
	@Test
	public void testGetLongUrlByShortUrl1() {
		expectedException.expect(BusinessException.class);
		shortDomainNameService.getLongUrlByShortUrl(SHORT_URL_2);
	}

	/**
	 * @Description 验证取已存在短链接逻辑
	 */
	@Test
	public void testGetLongUrlByShortUrl2() {
		Assert.assertEquals(shortDomainNameService.getLongUrlByShortUrl(SHORT_URL_1), LONG_URL_1);
	}

	/**
	 * @Description 验证短连接前缀错误逻辑
	 */
	@Test
	public void testGetLongUrlByShortUrl3() {
		expectedException.expect(BusinessException.class);
		shortDomainNameService.getLongUrlByShortUrl(ERROR_SHORT_URL);
	}

	/**
	 * @Description 验证输入字符串为空逻辑
	 */
	@Test
	public void testGetLongUrlByShortUrl4() {
		expectedException.expect(BusinessException.class);
		shortDomainNameService.getLongUrlByShortUrl(Strings.EMPTY);
	}

}
