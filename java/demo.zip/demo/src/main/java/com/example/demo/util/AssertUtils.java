package com.example.demo.util;

import java.util.List;

import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

/**
 * 校验类
 */
public final class AssertUtils extends Assert {
	
	 /**
     * spring boot 注解校验,异常统一抛出
     * @param bindingResult
     */
	public static void throwException(BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			StringBuffer buffer = new StringBuffer();
			List<ObjectError> errorList = bindingResult.getAllErrors();
			for (ObjectError objectError : errorList) {
				String objErr = objectError.getDefaultMessage();
				if (buffer.length()!=0) {
					buffer.append("    ").append(objErr);
				} else {
					buffer.append(objErr);
				}
			}
			throw new IllegalArgumentException(buffer.toString());
		}
	}
}
