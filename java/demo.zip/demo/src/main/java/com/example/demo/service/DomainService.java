package com.example.demo.service;

import com.example.demo.api.Domain;

public interface DomainService {

	String getShortUrl(Domain domain);

	String getLongUrl(String shortPath);

}
