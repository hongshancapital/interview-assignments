package com.example.demo.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.api.ApiResponse;
import com.example.demo.api.Domain;
import com.example.demo.service.DomainService;
import com.example.demo.util.AssertUtils;
import com.example.demo.util.ValidatorType;

@RestController
@Api(tags = "DomainController", description = "长短域名接口")
@RequestMapping("/demo/domain")
public class DomainController {
	
	@Autowired
    private DomainService domainService;
	
	@ApiOperation("短域名存储接口")
    @RequestMapping(value = "/short", method = RequestMethod.POST)
    public ApiResponse<String> getShortUrl(@Validated(ValidatorType.GroupAdd.class) 
    @RequestBody Domain domain, BindingResult bindingResult){
    	AssertUtils.throwException(bindingResult);
    	return ApiResponse.apiOK(domainService.getShortUrl(domain));
    }
    
	@ApiOperation("短域名读取接口")
    @RequestMapping(value = "/{shortPath}", method = RequestMethod.GET)
    public ApiResponse<String> getLongUrl(@PathVariable String shortPath){
    	return ApiResponse.apiOK(domainService.getLongUrl(shortPath));
    }
    
}
