package com.example.demo.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class AsyncUtil {
	
	public static ExecutorService executorservice = new ThreadPoolExecutor(5, 10, 2, TimeUnit.MINUTES,new LinkedBlockingQueue<Runnable>());

}
