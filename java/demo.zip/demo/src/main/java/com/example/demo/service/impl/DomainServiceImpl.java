package com.example.demo.service.impl;

import org.apache.commons.codec.digest.MurmurHash3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.demo.api.Domain;
import com.example.demo.service.DomainService;
import com.example.demo.util.AsyncUtil;
import com.example.demo.util.MathUtils;
@Service
public class DomainServiceImpl implements DomainService{
	
	@Autowired
	CacheManager cacheManager;

	@Override
	@Cacheable(value = "shortUrl", key = "#domain.getLongUrl()")
	public String getShortUrl(Domain domain) {
		long hash = MurmurHash3.hash32x86(domain.getLongUrl().getBytes());
		String shortUrl = MathUtils._10_to_62(hash);
		saveLongUrl(domain, shortUrl);
		return shortUrl;
	}


	@Override
	@Cacheable(value = "longUrl", key = "#shortPath")
	public String getLongUrl(String shortPath) {
		return null;
	}
	
	private void saveLongUrl(Domain domain, String shortUrl) {
		AsyncUtil.executorservice.execute(new Runnable() {
			@Override
			public void run() {
				Cache cache = cacheManager.getCache("longUrl");
				cache.put(shortUrl, domain.getLongUrl());
			}
		});
	}

}
