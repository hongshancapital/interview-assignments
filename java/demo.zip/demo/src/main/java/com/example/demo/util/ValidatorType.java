package com.example.demo.util;

/**
 * 校验模式常量类
 */
public class ValidatorType {
	
	public interface GroupAdd {};
	
	public interface GroupDelete {};
	
	public interface GroupUpdate {};
	
	public interface GroupSelect {};
	
}

