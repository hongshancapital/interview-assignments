package com.example.demo.api;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.example.demo.util.ValidatorType;



public class Domain  implements Serializable{
	
	private static final long serialVersionUID = -3811916690710455741L;

	@NotBlank(message="短域名不能为空！")
    @Length(max=8, message = "短域名长度不超过8！", groups = {ValidatorType.GroupSelect.class})
	private String shortUrl;
	
	// 考虑IE支持 2k Nginx默认4k 取最小
	@NotBlank(message="长域名不能为空！")
    @Length(max=2083, message = "长域名长度不超过2083！", groups = {ValidatorType.GroupAdd.class})
	private String longUrl;

	private String termOfValidity; // 短网址有效期
	public String getShortUrl() {
		return shortUrl;
	}

	public void setShortUrl(String shortUrl) {
		this.shortUrl = shortUrl;
	}

	public String getTermOfValidity() {
		return termOfValidity;
	}

	public void setTermOfValidity(String termOfValidity) {
		this.termOfValidity = termOfValidity;
	}

	public String getLongUrl() {
		return longUrl;
	}

	public void setLongUrl(String longUrl) {
		this.longUrl = longUrl;
	}
	
	

}
