package com.example.demo.config;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.api.ApiResponse;


@ControllerAdvice({"com.example.demo."})
@ResponseBody
public class GlobalExceptionHandler {
	private Logger logger = LoggerFactory
			.getLogger(GlobalExceptionHandler.class);

	public static final Integer EX_OTHER_CODE = 500;

	@ExceptionHandler(Exception.class)
	public ApiResponse otherExceptionHandler(HttpServletResponse response,
			Exception ex) {
		response.setStatus(500);
		logger.error(ex.getMessage(), ex);
		return ApiResponse.apiError(EX_OTHER_CODE, ex.getMessage());
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ApiResponse paramsCheckExceptionHandler(
			HttpServletResponse response, Exception ex) {
		response.setStatus(200);
		logger.error(ex.getMessage(), ex);
		return ApiResponse.apiError(211, ex.getMessage());
	}

}
