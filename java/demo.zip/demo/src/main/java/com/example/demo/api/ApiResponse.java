package com.example.demo.api;


import java.math.BigDecimal;
import java.util.List;

public class ApiResponse<T> {

    public static final int OK = 200;

    public static final String OK_MESSAGE = "执行成功";

    public static final int WARN = 201;

    public static final String WARN_MESSAGE = "执行警告";

    public static final int ERROR = 202;

    public static final String ERROR_MESSAGE = "执行错误";

    public static final int TOKEN_FORBIDDEN_CODE = 101;   //令牌禁止代码

    public static final int TOKEN_ERROR_CODE = 102; //令牌错误代码

    private int code;

    private T data;

    private String message;

    public ApiResponse(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public ApiResponse(int code, T data, String message) {
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public static <T> ApiResponse<T> apiOK() {
        return apiOK(null);
    }

    public static <T> ApiResponse<T> apiOK(T data) {
        return apiOK(data, OK_MESSAGE);
    }

    public static <T> ApiResponse<T> apiOK(T data, String message) {
        return getInstance(OK, data, message);
    }

    public static <T> ApiResponse<T> getInstance(int code, T data, String message) {
        return new ApiResponse<T>(code, data, message);
    }

    public static ApiResponse page(long total, List rows) {
        return apiOK(new PageData(total, rows));
    }
    
    public static ApiResponse pageCustomize(long total, List rows, BigDecimal totalValue) {
        return apiOK(new PageDataCustomize(total, rows, totalValue));
    }

    public static <T> ApiResponse<T> apiWarn(T data) {
        return apiWarn(data, WARN_MESSAGE);
    }

    public static <T> ApiResponse<T> apiWarn(T data, String message) {
        return new ApiResponse<T>(WARN, data, message);
    }

    public static <T> ApiResponse<T> apiWarn(String[] msg) {
        StringBuilder sb = new StringBuilder();
        for (String m : msg) {
            sb.append(m).append("<br/>");
        }
        return new ApiResponse(WARN, sb.toString(), null);
    }

//    public static <T> ApiResponse<T> apiWarn(T data, String[] msg) {
//        StringBuilder sb = new StringBuilder();
//        for (String m : msg) {
//            sb.append(m).append("<br/>");
//        }
//        return new ApiResponse<T>(WARN, data, sb.toString());
//    }

//    public static <T> ApiResponse<T> apiError(T data) {
//        return apiError(data, ERROR_MESSAGE);
//    }

//    public static <T> ApiResponse<T> apiError(T data, String message) {
//        return new ApiResponse<T>(ERROR, data, message);
//    }

    public static <T> ApiResponse<T> apiError(String message) {
        return apiError(ERROR, message);
    }

    public static <T> ApiResponse<T> apiError(int code, String message) {
        return new ApiResponse<T>(code, null, message);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ApiResponse() {
        super();
    }


    static class PageData {
        private long total;
        private List rows;

        public PageData(long total, List rows) {
            this.total = total;
            this.rows = rows;
        }

//        public static PageData getInstance(long total, List rows) {
//            return new PageData(total, rows);
//        }

        public long getTotal() {
            return total;
        }

        public void setTotal(long total) {
            this.total = total;
        }

        public List getRows() {
            return rows;
        }

        public void setRows(List rows) {
            this.rows = rows;
        }
    }
    
    static class PageDataCustomize {
        private long total;
        private List rows;
        private BigDecimal totalValue;

        public PageDataCustomize(long total, List rows, BigDecimal totalValue) {
            this.total = total;
            this.rows = rows;
            this.totalValue = totalValue;
        }

//        public static PageDataCustomize getInstance(long total, List rows, BigDecimal totalValue) {
//            return new PageDataCustomize(total, rows, totalValue);
//        }

        public long getTotal() {
            return total;
        }

        public void setTotal(long total) {
            this.total = total;
        }

        public List getRows() {
            return rows;
        }

        public void setRows(List rows) {
            this.rows = rows;
        }

		public BigDecimal getTotalValue() {
			return totalValue;
		}

		public void setTotalValue(BigDecimal totalValue) {
			this.totalValue = totalValue;
		}
    }
    
}
