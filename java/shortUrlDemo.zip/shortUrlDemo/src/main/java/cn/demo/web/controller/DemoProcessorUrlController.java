package cn.demo.web.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.demo.web.bo.ResultBean;
import cn.demo.web.utils.DemoProcessorUrlUtils;
/**
 * 短域名生成接口类
 * @author 亚洪财
 * @date 2021-03-08
 */
@RestController
public class DemoProcessorUrlController {

	/**
	 * 短域名生成
	 * @param url
	 * @return
	 */
    @RequestMapping("CreateShortUrl")
    public static ResultBean CreateShortUrl(String url){
    	
    	try {
    		String transformUrl = DemoProcessorUrlUtils.transformUrl(url);
    		return ResultBean.Success(transformUrl);
    	}catch (Exception e) {
    		return ResultBean.error(url,"错误原因，业务处理");
		}
    }

    /**
     * 长域名查询
     * @param shortUrl
     * @return
     */
    @RequestMapping("queryLongUrl")
    public static ResultBean queryLongUrl(String shortUrl){  	
    	try {
    		String transformUrl = DemoProcessorUrlUtils.findOriginalUrl(shortUrl);
    		return ResultBean.Success(transformUrl);
    	}catch (Exception e) {
    		return ResultBean.error(shortUrl,"错误原因，业务处理");
		}
    }
}



