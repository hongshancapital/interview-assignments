package cn.demo.web.bo;
/**
 * 短连接生成接口类
 * @author 亚洪财
 * @date 2021-03-08
 */
public class ResultBean {

	// 处理结果：‘0’代表成功，‘1’代表失败
	private String code;
	// 生成的网址，如果失败，则返回原链接
	private String url;
	// 异常描述
	private String err;

	public ResultBean() {
		
	}
	public ResultBean(String code, String url, String err) {
		this.code = code;
		this.url = url;
		this.err = err;
	}
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getErr() {
		return err;
	}

	public void setErr(String err) {
		this.err = err;
	}
	
	public static ResultBean Success(String url) {
		return new ResultBean("0",url,null);
	}
	public static ResultBean error(String url,String err) {
		return new ResultBean("1",url,err);
	}
}
