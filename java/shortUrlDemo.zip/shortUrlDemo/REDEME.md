短域名生成demo
亚洪财