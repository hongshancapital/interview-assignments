package com.scdt.assignment.scdtjavaassignment.service;

public interface ShortDomainNameGenerator {
    String generateShortDomainName();
}
