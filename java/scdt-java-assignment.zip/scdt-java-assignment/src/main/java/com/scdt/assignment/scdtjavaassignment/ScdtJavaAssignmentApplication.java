package com.scdt.assignment.scdtjavaassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScdtJavaAssignmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScdtJavaAssignmentApplication.class, args);
    }

}
