package com.scdt.assignment.scdtjavaassignment.service;

public interface Base62ValueGenerator {
    String generateBase62Value();
}
