package xiejin.java.interview.dto.response;

import lombok.Data;

/**
 * @author xiejin
 * @date 2021/3/20 11:18
 */
@Data
public class ShortUrlResponseDTO {


    private String shortUrl;

}
