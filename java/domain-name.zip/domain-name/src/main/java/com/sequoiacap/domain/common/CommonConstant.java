package com.sequoiacap.domain.common;

/**
 * 通用常量
 */
public class CommonConstant {

    public static final String HTTPS_PROTOCOL = "https";

    public static final String HTTP_PROTOCOL = "http";
}
