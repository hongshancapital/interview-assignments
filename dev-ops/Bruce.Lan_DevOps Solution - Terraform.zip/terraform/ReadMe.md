## Prerequisites
- AWS Account
- AWS CLI
- Terraform
- Docker
- Git

## Installation
- Clone this repository
- Create AWS IAM User
- Create AWS Access Key
- Configure AWS CLI
- Create AWS S3 Bucket
- Create AWS VPC
- Create AWS ECS
- Create AWS Task Definition
- Create AWS Service
- Create AWS CloudWatch

## Create AWS IAM User
- Go to AWS Console
- Go to IAM
- Go to Users
- Click Add user
- Fill User name
- Check Programmatic access
- Click Next: Permissions
- Click Attach existing policies directly
- Check AdministratorAccess
- Click Next: Tags
- Click Next: Review
- Click Create user
- Click Download .csv
- Click Close

## Create AWS Access Key
- Go to AWS Console
- Go to IAM
- Go to Users
- Click User name
- Click Security credentials
- Click Create access key
- Click Download .csv
- Click Close

## Configure AWS CLI
```
aws configure
```
- Fill AWS Access Key ID
- Fill AWS Secret Access Key
- Fill Default region name
- Fill Default output format

## Create AWS S3 Bucket
```
aws s3api create-bucket --bucket <bucket-name> --region <region-name> --create-bucket-configuration LocationConstraint=<region-name>
```

## Create AWS VPC
```
cd terraform/vpc
terraform init
terraform plan
terraform apply
```

## Create AWS ECS
```
cd terraform/ecs
terraform init
terraform plan
terraform apply
```

## Create AWS Task Definition
```
cd terraform/task
terraform init
terraform plan
terraform apply
```

## Create AWS Service
```
cd terraform/service
terraform init
terraform plan
terraform apply
```

## Create AWS CloudWatch
```
cd terraform/cloudwatch
terraform init
terraform plan
terraform apply
```

## Test
- Go to AWS Console
- Go to ECS
- Go to Clusters
- Click Cluster name
- Click Tasks
- Click Task ID
- Click Container name
- Click Logs
- Click View logs in CloudWatch
- Click Log stream name
- Click Last event
- Click Refresh