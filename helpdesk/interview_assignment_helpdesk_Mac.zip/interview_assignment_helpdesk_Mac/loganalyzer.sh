#!/bin/bash
#Sequoia Capital helpdesk interview home assignment
#Written by : Simon Cui   sunghwan.tsui@gmail.com
#Created date : 2020/10/18
#OS Version : Mac 10.14.6

#The script extracts information from log file, analyze and post json format result to a log server.
#step 1: convert log file into csv with separator ^, it's good with sample file, there might be log file including ^ in description, may improve in future.
#step 2: import csv file into sqlite database  ,sqlite single commandline tool has been downloaded to the same folder as this script.
#step 3: query required information from sqlite
#step 4: write result into json file
#step 5: post to log server

logfile_name="./Helpdesk_interview_data_set"

#only return lines including keywords error or failed.
keywords="description like '%error%' or description like '%failed%'"

echo "Processing log file to csv started."
#regular expression to match line start with datetime stamp and other columns
#regular expression to match process example:    com.apple.xpc.launchd[1] (com.apple.mdworker.bundles[56122]) 
#com.apple.xpc.launchd[1] are ignored since it's often not the process causes error.
#regular expression to match process example:   com.apple.xpc.launchd[1] (com.apple.xpc.launchd.domain.pid.mdmclient.56246)
#regular expression to match process example: syslogd[113]
sed -n 's/^[a-zA-Z]\{1,\}[[:space:]][0-9]\{1,2\}[[:space:]]\([0-2][0-9]\):[0-5][0-9]:[0-5][0-9][[:space:]]\([^[[:space:]]\{1,\}\)[[:space:]]\([^:]\{1,\}\):/\3\^\2\^\1\^/p' < $logfile_name \
	| sed 's/^[^(]\{1,\}(\([^\[]\{1,\}\)\[\([0-9]\{1,\}\)\])\^/\1^\2^/' \
		| sed 's/^[^(]\{1,\}(\([^)]\{1,\}\)\.\([0-9]\{1,\}\))\^/\1^\2^/' \
			| sed 's/^[^(]\{1,\}(\([^)]\{1,\}\))\^/\1^00000^/' \
			     | sed 's/^\([^[]\{1,\}\)\[\([0-9]\{1,\}\)\]\^/\1^\2^/'  > $logfile_name.csv

echo "Processing log file to csv completed."

#import to sqlite database
echo "Importing csv file into sqlite started."
sqlite3 log.db <<END_SQL
DROP TABLE iF EXISTS analyzed;
DROP TABLE IF EXISTS log; 
CREATE TABLE log(processName TEXT,  processId TEXT, deviceName TEXT,timeHour TEXT, description TEXT);
.separator ^
.import "$logfile_name.csv" log
CREATE TABLE analyzed(processName TEXT, deviceName TEXT, description TEXT,timeWindow TEXT, numberOfOccurrence INTEGER,  processId TEXT);

INSERT INTO analyzed(processName,deviceName,description,timeWindow, numberOfOccurrence,processId)
select processName, deviceName,description, (timeHour || '00-' || CAST((CAST(timeHour as INTEGER)+1)*100 as TEXT)) as timeWindow , count(*) as numberOfOccurrence,GROUP_CONCAT(processId) as processId
from log 
where $keywords
group by processName, deviceName, timeWindow,description;

END_SQL
echo "Importing csv file into sqlite completed."


echo "Converting result to json format started."
result=$(
sqlite3 log.db <<END_SQL
select json_object('processName', processName,'processId', processId, 'deviceName' ,deviceName, 'description' ,description, 'timeWindow', timeWindow, 'numberOfOccurrence',numberOfOccurrence)
from analyzed;
END_SQL
)
	
echo "[ $result ]" > $logfile_name.json
sed -i.bak -e 's/}$/},/'  $logfile_name.json

echo "Converting result to json format completed."

echo "Uploading result to log server started."
json_content=$(cat $logfile_name.json)
curl -i \
-H "Content-Type:application/json" \
-X POST --data "$json_content" "https://foo.com/bar"
echo "Uploading result to log server completed."

#-X POST --data "$json_content" "http://httpbin.org/post" 
#verified post json to httpbin.org site, it shows whatever posted there, the result looks good.

