﻿<#
Sequoia Capital helpdesk interview home assignment
Written by : Simon Cui   sunghwan.tsui@gmail.com
Created at : 2020/10/17
OS Version : Windows 10 Enterprise version 2004
Powershell Version : 5.1.19041.1

The script extracts information from log file, analyze and post json format result to a log server.
#>



#create a datable to store analyzing result
$dt = New-Object System.Data.DataTable
$dt.Columns.Add("deviceName","string") | Out-Null
$dt.Columns.Add("processId","string") | Out-Null
$dt.Columns.Add("processName","string") | Out-Null
$dt.Columns.Add("description","string") | Out-Null
$dt.Columns.Add("timeWindow","string") | Out-Null
$dt.Columns.Add("numberOfOccurrence","int32") | Out-Null


#read log file 
$logfile_name="Helpdesk_interview_data_set"
$logfile_fullpath = "$PSScriptRoot\$logfile_name"
$log = Get-Content -Path $logfile_fullpath

#regular expression to match log line
$reg_line = '^\S+\s\S+\s(\S+)\s(\S+)\s([^:]+):\s(.+)'
#keywords to search from log description,change the keywords if required.
$keywords = 'error|failed'

#regular expression to match process example:   com.apple.xpc.launchd[1] (com.apple.xpc.launchd.domain.pid.mdmclient.56246)
#com.apple.xpc.launchd[1] are ignored since it's often not the process causes error.
$reg_process_1 = '.+\((.+)\.([0-9]+)\)$'
#regular expression to match process example:    com.apple.xpc.launchd[1] (com.apple.mdworker.bundles[56122])   
$reg_process_2 = '.+\((.+)\[([0-9]+)\]\)$'
#regular expression to match process example: syslogd[113]
$reg_process_3 = '(.+)\[([0-9]+)\]$'
#sample log file lines 33~line 80 look different than others, they're not in one line so they're ignored actually.

#read content of log file
foreach ($line in $log)
{
 
    if ( ($line -match $keywords) -and ($line -match $reg_line) )
    {
    $time = $Matches[1]
    $deviceName = $Matches[2]
    $process = $Matches[3]
    $description = $Matches[4]
    $processName = ""
    $processId = ""

    #only analyze line with correct time format HH:mm:ss
    if ($time -match '([0-2][0-9]):[0-5][0-9]:[0-5][0-9]')
    {
        #get hour from time stamp
        $hour = $Matches[1]
        #caclculate timeWindow
        $timeWindow_end=[string](100+[int]$hour+1)
        $timeWindow="{0}00-{1}00" -f $hour ,  $timeWindow_end.Substring($timeWindow_end.Length-2,2)

        #extract process name and process id
        if ($process -match $reg_process_1)
        {
        $processName = $Matches[1]
        $processId = $Matches[2]
        }
        elseif ($process -match $reg_process_2)
        {
            $processName = $Matches[1]
            $processId = $Matches[2]
        }
        elseif ($process -match $reg_process_3)
        {
            $processName = $Matches[1]
            $processId = $Matches[2]
        }
        #If there has been log with same process name, timewindow, description, update Occurrence number else add new row
        #In the sample log file, no lines have same <processName,processId,timewindow,desciprtion>, almost all occurence numbers are 1
        #So processId is excluded from , only <processName,processId,timeWindow,description> are compared.
        $occurrence = $dt.Where({ $_.processName -eq $processName -and $_.timeWindow -eq $timeWindow -and $_.description -eq $description})
        
        if ($occurrence.Count -eq 0)
        
        {
        #add new row
        $newrow = $dt.NewRow()
        $newrow.timeWindow = $timeWindow
        $newrow.deviceName = $deviceName
        $newrow.processId = $processId
        $newrow.processName = $processName
        $newrow.description = $description
        $newrow.numberOfOccurrence = 1 
        $dt.Rows.Add($newrow)

        }        
        else
        {
            #update existing row
            $occurrence[0].numberOfOccurrence = $occurrence[0].numberOfOccurrence+1
            $occurrence[0].processId = $occurrence[0].processId + "," + $processId
        }
   
    }

    }

    
}

#convert to Json format exlude useless object
$dt | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors| ConvertTo-Json | Out-File -FilePath "$logfile.json"


##solve SSL certificate issue
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

#post json file to the server , assume https://foo.com/bar accept json post
$body =  Get-Content("$logfile_fullpath.json") -Raw  
$Response = Invoke-WebRequest -Uri https://foo.com/bar -ContentType application/json -Method POST -Body $body

#verified on http://httpbin.org/post , it returns whatever posted there
$Response = Invoke-WebRequest -Uri http://httpbin.org/post -ContentType application/json -Method POST -Body $body
$Response.Content  


