### Q3

假设目前我们有一个日志文件是这样的格式, 可以假设字符串开始（无空格），然后一个空格，然后一个正整数。
使用任何方式，来对这个文件内容按照数字从大到小进行排序。如果是代码，请附加代码，如果是命令行，请附加命令行。


输入样例:

`

	foo 1 
	bar 4 
	footer 3 
	testline 5 
	dafsd812342 9

`

****************************以下为解题思路********************************
####需求分析：
1. 从需求得知，我们需要创建一个实体对象LogInfo，其中包括两个属性，一个是字符串logStr，另一个是正整数num，因为比较中要使用num，需要生成其get方法。
2. 由于输出格式有特定限制，那么我们需要重写该类的toString方法，令其满足我们的要求。
3. 题目中规定了要输入样例，所以，假设我们是需要从控制台输入，我们要使用到Scanner类
4. 需要对数组进行排序，每个数组元素需要比较（数组长度-1）次,我们来使用冒泡排序。
5. 在此过程中我们需要使用对象数组

####Java代码如下：

LogInfo类：

`

		public class LogInfo {
    	private String logStr;
    	private int num;

    	public LogInfo(String logStr, int num) {
        	this.logStr = logStr;
        	this.num = num;
    	}

    	@Override
    	public String toString() {
        	return logStr + " "+num;
    	}

    	public int getNum() {
        	return num;
    	}
	}

      
`

主方法类：

`

		import java.util.Scanner;
		public class SortString {
    		public static void main(String[] args) {
        		Scanner sc = new Scanner(System.in);
        		System.out.println("请输入5组样例: ");
        		LogInfo logInfo1 = new LogInfo(sc.next(),sc.nextInt());
        		LogInfo logInfo2 = new LogInfo(sc.next(),sc.nextInt());
        		LogInfo logInfo3 = new LogInfo(sc.next(),sc.nextInt());
        		LogInfo logInfo4 = new LogInfo(sc.next(),sc.nextInt());
        		LogInfo logInfo5 = new LogInfo(sc.next(),sc.nextInt());
        		LogInfo[] loginfos = new LogInfo[] {logInfo1,logInfo2,logInfo3,logInfo4,logInfo5};
        
        		//冒泡排序
        		LogInfo temp;
        		for (int i = 0; i < loginfos.length-1; i++) {
            		for (int j = 0; j < loginfos.length - 1; j++) {
                		if(loginfos[j].getNum()<loginfos[j+1].getNum()){
                    		temp = loginfos[j];
                    		loginfos[j] = loginfos[j+1];
                    		loginfos[j+1] = temp;
                		}
            		}
        		}
        		//输出排序后的结果
        		System.out.println("=========================================");
        		System.out.println("输出的结果为: ");
        		for (int i = 0; i < loginfos.length; i++) {
            		System.out.println(loginfos[i]);
        		}
    		}
		}


      
`

控制台结果：

`

		请输入5组样例: 
		foo 1
		bar 4
		footer 3
		testline 5
		dafsd812342 9
		=========================================
		输出的结果为: 
		dafsd812342 9
		testline 5
		bar 4
		footer 3
		foo 1

		Process finished with exit code 0

      
`









