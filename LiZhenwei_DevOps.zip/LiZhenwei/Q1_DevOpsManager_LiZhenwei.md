### Q1

分析系统日志。DevOps_interview_data_set.gz

分析系统日志得到关键信息，用Json的格式POST上传至服务器 https://foo.com/bar )，key的名称在括号里

1. 设备名称: (deviceName)
2. 错误的进程号码: (processId)
3. 进程/服务名称: (processName)
3. 错误的原因（描述）(description)
4. 发生的时间（小时级），例如0100-0200，0300-0400, (timeWindow)
4. 在小时级别内发生的次数 (numberOfOccurrence)

分别使用

1. Bash 或其他脚本语言，假设在Mac环境下，进行操作
2. Powershell，假设在windows环境下，进行操作

****************************以下为解题思路********************************
####需求分析：
从需求得知字段样式示例如下:

"deviceName"："BBAOMACBOOKAIR2"

"processId"： "com.apple.xpc.launchd[1]"

"processName": "com.apple.mdworker.bundles"

"description": "Service exited with abnormal code: 78"

发生的时间跨度：一天内从00：00到23：59,分24个区间

要区别对待：--- last message repeated 1 time ---

发生的次数numberOfOccurrence，根据题目要求需要统计每个小时区间下相同错误的次数。

从文件分析中得知，此文件包含两个主机，统计错误描述和相关数据的时候，要考虑并尽量合并去除因进程号码不相同而产生相同抛错的日志信息。

要忽略其中的一些warning，如

灵活处理一些报错，如AMPDeviceDiscoveryAgent，需要忽略报错的信息mux-device的尾部序号，将一些无关紧要的如Entered:合并进description,将一些无关描述合并进processId，为了正确无歧义显示，可以允许processId和processName一致，如：
`

	{
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "41"
    }
      
`




####技术实现：

如果要用shell bash脚本，常用的命令为awk，uniq -c，sort -nr
使用日期正则表达式，统计某个时间段的发生数量。

当然也可以用java来截取日志，做数组存储，最终统计报错数量。


###PS: 已经尝试将Json结果使用postman post上传到服务器，但是目前服务器返回not found, 如图：
![服务器情况](../pic/003.jpg)

###题目中没有给定特定的header，也没有给定用户如何做区分的param，为了能让面试官有更详细的了解：

####最终json结果(为了便于展示，暂时使用数组)：

    [{
        "deviceName": "bogon",
        "processId": "timed[158]",
        "description": "settimeofday({0x5ebb9332,0x1d51e},) == 0",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "bogon",
        "processId": "xpcproxy",
        "processName": "libcoreservices",
        "description": "_dirhelper_userdir: 557: bootstrap_look_up returned (ipc/send) invalid destination port",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "bogon",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "bogon",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0200-0300",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "16"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0400-0500",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0500-0600",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0600-0700",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "16"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "0900-1000",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1000-1100",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "18"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "18"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "8"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "11"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Could not find uid associated with service: 0: Undefined error: 0 501",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0200-0300",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "16"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0400-0500",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0500-0600",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0600-0700",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "16"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "0900-1000",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1000-1100",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "18"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "18"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "8"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "11"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "15"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.mdworker.bundles",
        "description": "Service exited with abnormal code: 78",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "19"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.ScreenSaver.Computer-Name",
        "description": "Service exited due to SIGKILL | sent by Computer Name",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.ScreenSaver.Computer-Name",
        "description": "Service exited due to SIGKILL | sent by Computer Name",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.ScreenSaver.Computer-Name",
        "description": "Service exited due to SIGKILL | sent by Computer Name",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0200-0300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0400-0500",
        "numberOfOccurrence": "3"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0500-0600",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "0900-1000",
        "numberOfOccurrence": "4"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "4"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.pid.mdmclient",
        "description": "Failed to bootstrap path: path = /usr/libexec/mdmclient, error = 108: Invalid path",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "3"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "4"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "com.apple.xpc.launchd[1]",
        "processName": "com.apple.xpc.launchd.domain.user",
        "description": "Service 'com.apple.xpc.launchd.unmanaged.loginwindow.594' tried to register for endpoint 'com.apple.tsm.uiserver' already registered by owner: com.apple.TextInputMenuAgent",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "4"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0200-0300",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0400-0500",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0500-0600",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0600-0700",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "0900-1000",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1000-1100",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "4"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "5"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "1800-1900",
        "numberOfOccurrence": "3"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "2000-2100",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "2100-2200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syslogd[113]",
        "processName": null,
        "description": "ASL Sender Statistics",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "6"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "0000-0100",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "1800-1900",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "2000-2100",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "timed[158]",
        "processName": null,
        "description": "settimeofday({**********,********},) == 0",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "VTDecoderXPCService",
        "processName": "DEPRECATED USE in libdispatch client",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1000-1100",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing the target of a source after it has been activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0100-0200",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0300-0400",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0700-0800",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "0800-0900",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1000-1100",
        "numberOfOccurrence": "2"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1100-1200",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "1500-1600",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2200-2300",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "syncdefaultsd",
        "processName": "objc",
        "description": "Changing target queue hierarchy after xpc connection was activated; set a breakpoint on _dispatch_bug_deprecated to debug",
        "timeWindow": "2300-2400",
        "numberOfOccurrence": "1"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "41"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Mux ID not found in mapping dictionary",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "41"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "41"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Can't handle disconnect with invalid ecid",
        "timeWindow": "1200-1300",
        "numberOfOccurrence": "41"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "21"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Mux ID not found in mapping dictionary",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "21"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "21"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Can't handle disconnect with invalid ecid",
        "timeWindow": "1300-1400",
        "numberOfOccurrence": "21"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "33"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Mux ID not found in mapping dictionary",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "33"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "33"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Can't handle disconnect with invalid ecid",
        "timeWindow": "1400-1500",
        "numberOfOccurrence": "33"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Mux ID not found in mapping dictionary",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Can't handle disconnect with invalid ecid",
        "timeWindow": "1600-1700",
        "numberOfOccurrence": "17"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "34"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Mux ID not found in mapping dictionary",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "34"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "Entered:__thr_AMMuxedDeviceDisconnected, mux-device***",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "34"
    },
    {
        "deviceName": "BBAOMACBOOKAIR2",
        "processId": "AMPDeviceDiscoveryAgent[976]",
        "processName": "AMPDeviceDiscoveryAgent",
        "description": "tid:9427 - Can't handle disconnect with invalid ecid",
        "timeWindow": "1700-1800",
        "numberOfOccurrence": "34"
    }]






