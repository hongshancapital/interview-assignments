### Q2

使用CDK，搭建一套Fargate + ALB/NLB 的应用（应用可以参考 https://hub.docker.com/r/amazon/amazon-ecs-sample ），在私有网络的VPC环境中（无公网访问）

#### 注意
- VPC的子网 no public assign attribute

#### Bonus
WAF配置

使用Typescript 编写相关CDK脚本


#根据分析可以得到，解题的大概步骤为：

	第一步：初始化AWS CLI
	第二步：使用AWS CDK创建一个AWS Farget+ALB服务，要注意引用镜像amazon/amazon-ecs-sample
	第三步：最终结果检验
	第四步：销毁，因为服务即资源，不能浪费，确保试验完成释放资源。

	在此过程中，需要使用TypeScript去编写脚本。

##### 第一步：初始化AWS-CLI：

1. 初始化一个EC2虚拟机，名叫: amazon-ecs-Sequoia-Capital-DevOps-Q2，如图所示:
![基础环境准备](../pic/001.jpg)
	
2. 初始化AWS命令行(typescript@4.1.3)

		yum -y install npm
		npm install -g typescript
3. 用非root账号执行（aws-cdk/aws-s3/aws-lambda@1.78.0）：

		npm install @aws-cdk/aws-s3 @aws-cdk/aws-lambda


##### 第二步：使用AWS CDK创建一个AWS Farget+ALB服务
1. 创建一个文件夹，并初始化cdk,语言选择typescript:

		cd /opt
		mkdir MyEcsConstruct
		cd MyEcsConstruct
		cdk init --language typescript

2. 运行cdk应用程序，并确认它创建了一个空栈

		cdk synth

		输出：
		Resources:
  		CDKMetadata：
    	Type: AWS::CDK::Metadata
    	Properties:
      	Modules: aws-cdk=1.78.0,@aws-cdk/core=1.78.0,@aws-cdk/cx-api=1.78.0,jsii-runtime=node.js/v6.17.1

3. 添加Amazon EC2和Amazon ECS软件包

		npm install @aws-cdk/aws-ec2 @aws-cdk/aws-ecs @aws-cdk/aws-ecs-patterns

4. 创建Fargate服务（在ECS中有EC2和Fargate两种方式，按照题干我们选择第二种Fargate）：
	 
	修改创建文件: lib/my_ecs_construct-stack.ts

		import * as ec2 from "@aws-cdk/aws-ec2";
		import * as ecs from "@aws-cdk/aws-ecs";
		import * as ecs_patterns from "@aws-cdk/aws-ecs-patterns";
		const vpc = new ec2.Vpc(this, "MyVpc", {
      	maxAzs: 3 // 默认为所有
    	});

    	const cluster = new ecs.Cluster(this, "MyCluster", {
      		vpc: vpc
    	});

    	// 根据题干要求创建一个公用的应用负载均衡Fargate服务
		//根据题干要求Fargate + ALB
    	new ecs_patterns.ApplicationLoadBalancedFargateService(this, "MyFargateService", {
      		cluster: cluster, // 必须的
      		cpu: 512, // 默认为256
      		desiredCount: 3, // 默认为1，此处可以后续用来检验ALB
			//根据题干要求，引用amazon/amazon-ecs-sample
      		taskImageOptions: { image: ecs.ContainerImage.fromRegistry("amazon/amazon-ecs-sample") },
      		memoryLimitMiB: 2048, // 默认为512
      		publicLoadBalancer: true // 默认为false
    	});

4. 保存并确保运行并创建堆栈：

		cdk synth
5. 部署：

		cdk deploy

##### 第三步：最终结果检验
![sample PHP App运行情况](../pic/002.jpg)

##### 第四步：销毁，释放测试资源

		cdk destroy

		
		



