package com.jiajia.shortUrl.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;


@EnableAutoConfiguration()
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UrlControllerTest {
	@Autowired
    private TestRestTemplate restTemplate;
	
	private static final Logger logger = LoggerFactory.getLogger(UrlControllerTest.class);

	@Test
	public void testSaveUrl() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		MultiValueMap<String, Object> saveJson = new LinkedMultiValueMap<>();
		saveJson.add("longUrl", "https://blog.csdn.net/zyq940238856/article/details/88877036");
		String sUrl = restTemplate.postForObject("/saveShortUrl", new HttpEntity<>(saveJson,headers),String.class);
		logger.info("sUrl="+sUrl);
	}
	
	@Test
	public void testgetUrl() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		MultiValueMap<String, Object> saveJson = new LinkedMultiValueMap<>();
		saveJson.add("longUrl", "https://blog.csdn.net/zyq940238856/article/details/88877036");
		String sUrl = restTemplate.postForObject("/saveShortUrl", new HttpEntity<>(saveJson,headers),String.class);
		logger.info("sUrl="+sUrl);
		MultiValueMap<String, Object> getJson = new LinkedMultiValueMap<>();
		getJson.add("shortUrl", sUrl);
		String lUrl = restTemplate.postForObject("/getLongUrl", new HttpEntity<>(getJson,headers),String.class);
		logger.info("lUrl="+lUrl);
	}

}
