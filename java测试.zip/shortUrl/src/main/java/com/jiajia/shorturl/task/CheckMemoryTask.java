package com.jiajia.shorturl.task;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jiajia.shorturl.conf.Config;

@Component
public class CheckMemoryTask {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
    private int i;

    /*
     *定时进行内存使用扫描，内存使用超过80%，停止短域名申请服务 
     **/
    @Scheduled(cron = "*/60 * * * * ?")
    public void execute() {
    	long freeM = Runtime.getRuntime().freeMemory();
    	long totalM = Runtime.getRuntime().totalMemory();
    	BigDecimal bFree = new BigDecimal(freeM);
    	BigDecimal bTotal = new BigDecimal(totalM);
    	BigDecimal rateM = bFree.divide(bTotal,3,1);
    	if(rateM.doubleValue()<0.2) {
    		Config.SAVE_FLAG.set(1);
    	}else {
    		Config.SAVE_FLAG.set(0);
    	}
    }

}
