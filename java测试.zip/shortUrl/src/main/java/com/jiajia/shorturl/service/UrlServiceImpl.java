package com.jiajia.shorturl.service;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jiajia.shorturl.conf.Config;
import com.jiajia.shorturl.util.UrlTranform;

//@Component("urlService")
@Service
public class UrlServiceImpl implements IUrlService{
	
	public String getLongUrl(String shortUrl) {
		String longUrl = (String)Config.SHORTMAP.get(shortUrl);
		if(StringUtils.isEmpty(longUrl)) {
			longUrl = Config.ERROR1;
		}
		return longUrl;
	}
	
	public synchronized String saveShortUrl(String longUrl) {
		String shortUrl = (String)Config.LONGMAP.get(longUrl);
		if(StringUtils.isEmpty(shortUrl)) {
			if(Config.SAVE_FLAG.get()==0) {
				int index = (int)(Math.random()*4);
				UrlTranform ut = new UrlTranform();
				String[] shorts = ut.shortUrl(longUrl);
				shortUrl = shorts[index];			
				Config.SHORTMAP.put(shortUrl, longUrl);
				Config.LONGMAP.put(longUrl, shortUrl);
			}else {
				shortUrl = Config.ERROR0;
			}
		}
			
		return shortUrl;
	}

}
