package com.jiajia.shorturl.service;

import org.springframework.stereotype.Component;

public interface IUrlService{
	
	public String getLongUrl(String longUrl);
	
	public String saveShortUrl(String longUrl);

}
