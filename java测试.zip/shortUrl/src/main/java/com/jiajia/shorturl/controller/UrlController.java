package com.jiajia.shorturl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jiajia.shorturl.conf.Config;
import com.jiajia.shorturl.service.IUrlService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = "短域名服务接口")
public class UrlController {
	
	@Autowired
	private IUrlService urlService;
	
	@RequestMapping(value="",method = RequestMethod.GET)
	@ApiOperation("hello world接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "username", value = "用户名", defaultValue = "李四"),
            @ApiImplicitParam(name = "address", value = "用户地址", defaultValue = "深圳", required = true)
    }
    )
    public String getText(){
         return "hello world2";
    }
	
	@RequestMapping(value="/saveShortUrl",method = RequestMethod.POST)
	@ApiOperation(value = "存储短域名", notes="输入长域名信息，返回短域名")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "longUrl", value = "长域名地址", defaultValue = "www.baidu.com", required = true)
    	}
    )
	public String saveShortUrl(@RequestParam(name = "longUrl",required = true) String longUrl) {
		String sUrl = urlService.saveShortUrl(longUrl);
		String result = "";
		if(!StringUtils.isEmpty(sUrl) && !sUrl.equals(Config.ERROR0)) {
			result = Config.PREFIX + sUrl;
		}else {
			result = sUrl;
		}
        return result;
    }
	
	@RequestMapping(value="/getLongUrl",method = RequestMethod.POST)
	@ApiOperation(value = "根据短域名获得相应的长域名", notes="输入短域名信息，返回长域名")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "shortUrl", value = "短域名地址", defaultValue = "http://jia/BviUVfaa", required = true)
    	}
    )
	public String getLongUrl(@RequestParam(name = "shortUrl",required = true) String shortUrl) {
		String result = "";
		if(shortUrl.startsWith(Config.PREFIX)) {
			String sUrl = shortUrl.substring(11);
			result = urlService.getLongUrl(sUrl);
		}else {
			result = Config.ERROR1;
		}
        return result;
    }

}
