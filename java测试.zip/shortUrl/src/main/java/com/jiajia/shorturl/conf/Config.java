package com.jiajia.shorturl.conf;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class Config {
	
	//内存检查标志位
	public static AtomicInteger SAVE_FLAG = new AtomicInteger(0); 
	//存储短域名与长域名
	public static ConcurrentHashMap SHORTMAP = new ConcurrentHashMap<String,String>();
	//存储长域名与短域名
	public static ConcurrentHashMap LONGMAP = new ConcurrentHashMap<String,String>();
	//内存使用过多时返回错误信息
	public static String ERROR0 = "service is pause";
	//短域名不存在时返回错误信息
	public static String ERROR1 = "url is not found";
	//短域名前缀
	public static String PREFIX = "http://jia/";

}
