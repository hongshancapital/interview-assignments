import React from "react";
import "./App.css";
import Carouse from "./component/Carousel"
function App() {
  return <div className="App"><Carouse >
  <div>1</div>
  <div>2</div>
  <div>3</div>
  </Carouse></div>;
}

export default App;
