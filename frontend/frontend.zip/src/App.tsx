import React from "react";
import "./App.css";

function App() {
  return <div className="App">{/* write your component here */}</div>;
}

export default App;
