//
//  ContentView.swift
//  TodoList_SwiftUI
//
//  Created by zengmuqiang on 2021/11/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, world!")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
